/**
 * Utility for formatting currency in Pakistani Rupee (PKR)
 */
export function formatPKR(amount: number): string {
  if (isNaN(amount)) return 'Rs. 0';
  return `Rs. ${new Intl.NumberFormat('en-PK').format(Math.round(amount))}`;
}

export function calculateShipping(subtotal: number): number {
  if (subtotal <= 0) return 0;
  // Free shipping over PKR 3,000 nationwide
  if (subtotal >= 3000) return 0;
  return 250;
}
