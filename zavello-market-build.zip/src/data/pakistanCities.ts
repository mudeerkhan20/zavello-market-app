export interface PakistanCity {
  name: string;
  province: string;
  estimatedDays: string;
}

export const PAKISTAN_CITIES: PakistanCity[] = [
  { name: 'Karachi', province: 'Sindh', estimatedDays: '2-4 business days' },
  { name: 'Lahore', province: 'Punjab', estimatedDays: '2-3 business days' },
  { name: 'Islamabad', province: 'Federal', estimatedDays: '2-3 business days' },
  { name: 'Rawalpindi', province: 'Punjab', estimatedDays: '2-3 business days' },
  { name: 'Faisalabad', province: 'Punjab', estimatedDays: '3-4 business days' },
  { name: 'Multan', province: 'Punjab', estimatedDays: '3-4 business days' },
  { name: 'Peshawar', province: 'Khyber Pakhtunkhwa', estimatedDays: '3-5 business days' },
  { name: 'Quetta', province: 'Balochistan', estimatedDays: '4-6 business days' },
  { name: 'Sialkot', province: 'Punjab', estimatedDays: '3-4 business days' },
  { name: 'Gujranwala', province: 'Punjab', estimatedDays: '3-4 business days' },
  { name: 'Hyderabad', province: 'Sindh', estimatedDays: '3-5 business days' },
  { name: 'Abbottabad', province: 'Khyber Pakhtunkhwa', estimatedDays: '3-5 business days' },
  { name: 'Bahawalpur', province: 'Punjab', estimatedDays: '3-5 business days' },
  { name: 'Sargodha', province: 'Punjab', estimatedDays: '3-5 business days' },
  { name: 'Sukkur', province: 'Sindh', estimatedDays: '3-5 business days' },
  { name: 'Larkana', province: 'Sindh', estimatedDays: '4-6 business days' },
  { name: 'Sheikhupura', province: 'Punjab', estimatedDays: '3-4 business days' },
  { name: 'Rahim Yar Khan', province: 'Punjab', estimatedDays: '3-5 business days' },
  { name: 'Jhelum', province: 'Punjab', estimatedDays: '3-4 business days' },
  { name: 'Gujrat', province: 'Punjab', estimatedDays: '3-4 business days' },
  { name: 'Mardan', province: 'Khyber Pakhtunkhwa', estimatedDays: '3-5 business days' },
  { name: 'Sahiwal', province: 'Punjab', estimatedDays: '3-4 business days' },
  { name: 'Other (Enter Custom City)', province: 'Pakistan', estimatedDays: '3-6 business days' },
];
