import { Product } from '../types';

export const SAMPLE_PRODUCTS: Product[] = [
  // --- FASHION ---
  {
    id: 'zm-fsh-01',
    slug: 'pure-linen-minimal-co-ord-set',
    name: 'Pure Linen Minimalist Co-Ord Set',
    category: 'fashion',
    categoryLabel: 'Fashion',
    price: 4650,
    compareAtPrice: 5800,
    images: [
      'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'A breathable, tailored two-piece co-ord set crafted from lightweight linen blend. Perfect for everyday casual wear and semi-formal outings in Pakistan’s warm seasons.',
    features: [
      'Breathable organic linen-cotton blend',
      'Relaxed straight-cut trousers with elasticated waistband',
      'Minimal collar detail with coconut-shell buttons',
      'Pre-shrunk fabric to prevent post-wash shrinkage'
    ],
    availability: 'in_stock',
    availabilityNote: 'Supplier stock active. Size availability verified with supplier upon order.',
    estimatedDelivery: '3-4 business days nationwide',
    variants: [
      { name: 'Size', options: ['Small', 'Medium', 'Large', 'Extra Large'] },
      { name: 'Color', options: ['Oatmeal Beige', 'Sage Olive', 'Midnight Slate'] }
    ],
    featured: true,
    isPopular: true,
    sku: 'ZM-FSH-001',
    internalSupplierNotes: 'Supplier partner: Lahore Textile Mills Hub. Lead time: 24h.'
  },
  {
    id: 'zm-fsh-02',
    slug: 'embroidered-organza-luxe-kurti',
    name: 'Floral Embroidered Organza Kurti',
    category: 'fashion',
    categoryLabel: 'Fashion',
    price: 3850,
    compareAtPrice: 4500,
    images: [
      'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1529139574466-a303027c1d8b?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Graceful semi-formal kurti featuring delicate thread embroidery on premium sheer organza with an attached soft viscose slip for full coverage.',
    features: [
      'Fine resham thread embroidery on sleeves and neckline',
      'Includes breathable attached inner slip',
      'Comfortable A-line silhouette with side slits',
      'Dry clean recommended'
    ],
    availability: 'in_stock',
    availabilityNote: 'Handcrafted run; stock replenished on supplier schedule.',
    estimatedDelivery: '3-5 business days across Pakistan',
    variants: [
      { name: 'Size', options: ['Small (Chest 36")', 'Medium (Chest 40")', 'Large (Chest 44")'] },
      { name: 'Color', options: ['Tea Pink', 'Ivory Cream', 'Lilac Mist'] }
    ],
    featured: true,
    isNew: true,
    sku: 'ZM-FSH-002'
  },
  {
    id: 'zm-fsh-03',
    slug: 'relaxed-cotton-oxford-shirt',
    name: 'Relaxed Tailored Cotton Shirt',
    category: 'fashion',
    categoryLabel: 'Fashion',
    price: 2450,
    compareAtPrice: 3200,
    images: [
      'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Crisp 100% combed cotton shirt with subtle structured tailoring. A versatile wardrobe foundation for work, university, or evening gatherings.',
    features: [
      '100% fine combed breathable cotton',
      'Reinforced seams and mother-of-pearl style buttons',
      'Tailored regular fit',
      'Machine washable easy-care finish'
    ],
    availability: 'in_stock',
    availabilityNote: 'Standard batch inventory confirmed with partner workshop.',
    estimatedDelivery: '2-4 business days',
    variants: [
      { name: 'Size', options: ['Small', 'Medium', 'Large', 'XL'] },
      { name: 'Color', options: ['Sky Blue', 'Crisp White', 'Olive Dusk'] }
    ],
    isPopular: true,
    sku: 'ZM-FSH-003'
  },

  // --- BEAUTY & COSMETICS ---
  {
    id: 'zm-bty-01',
    slug: 'velvet-matte-cloud-lip-cream',
    name: 'Velvet Matte Cloud Lip Cream',
    category: 'beauty',
    categoryLabel: 'Beauty & Cosmetics',
    price: 1350,
    compareAtPrice: 1750,
    images: [
      'https://images.unsplash.com/photo-1586495777744-4413f21062fa?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1627384113743-6bd5a479fffd?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Feather-light whipped lip mousse that deposits high-pigment velvet color without flaking or drying lips. Enriched with vitamin E and jojoba oil.',
    features: [
      'Weightless airy formula with 8-hour wear',
      'Non-drying, smudge-resistant velvet finish',
      'Infused with Vitamin E and Jojoba seed oil',
      'Precision doe-foot applicator'
    ],
    availability: 'in_stock',
    availabilityNote: 'Verified fresh batch. Checked before dispatch.',
    estimatedDelivery: '2-4 business days',
    variants: [
      { name: 'Shade', options: ['01 Rosewood Kashmiri', '02 Nude Caramel', '03 Spiced Cinnamon', '04 Berry Plum'] }
    ],
    featured: true,
    isPopular: true,
    sku: 'ZM-BTY-001'
  },
  {
    id: 'zm-bty-02',
    slug: 'dewy-glow-hydrating-primer-serum',
    name: 'Dewy Glow Hydrating Primer Serum',
    category: 'beauty',
    categoryLabel: 'Beauty & Cosmetics',
    price: 1850,
    compareAtPrice: 2400,
    images: [
      'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Multitasking hybrid primer and skin serum that locks in moisture, smooths skin texture, and leaves a glass-skin radiant sheen under makeup or on bare skin.',
    features: [
      'Formulated with 2% Hyaluronic Acid & Niacinamide',
      'Oil-free, non-comedogenic water-gel texture',
      'Extends makeup hold while controlling midday shine',
      'Suitable for sensitive and acne-prone skin'
    ],
    availability: 'in_stock',
    availabilityNote: 'Supplier batches restocked bi-weekly.',
    estimatedDelivery: '2-4 business days',
    variants: [
      { name: 'Size', options: ['30ml Standard Dropper', '50ml Deluxe Bottle'] }
    ],
    isNew: true,
    sku: 'ZM-BTY-002'
  },
  {
    id: 'zm-bty-03',
    slug: 'volumizing-curl-waterproof-mascara',
    name: 'Panoramic Volume & Lift Mascara',
    category: 'beauty',
    categoryLabel: 'Beauty & Cosmetics',
    price: 1150,
    compareAtPrice: 1500,
    images: [
      'https://images.unsplash.com/photo-1591360236480-4ed861025fa1?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1512496015851-a90fb38ba796?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Clump-free, humidity-resistant mascara designed to lift Pakistani lashes against heat and humidity. Smudge-proof all day long.',
    features: [
      'Hourglass flex brush captures every tiny lash',
      'Humidity and sweat resistant formula',
      'Deep carbon black mineral pigments',
      'Easily washes off with warm micellar water'
    ],
    availability: 'in_stock',
    availabilityNote: 'Verified cosmetics supplier batch.',
    estimatedDelivery: '2-4 business days',
    variants: [
      { name: 'Color', options: ['Intense Carbon Black', 'Soft Espresso Brown'] }
    ],
    sku: 'ZM-BTY-003'
  },

  // --- BODY CARE ---
  {
    id: 'zm-bdy-01',
    slug: 'argan-shea-velvet-body-lotion',
    name: 'Moroccan Argan & Shea Velvet Body Lotion',
    category: 'body-care',
    categoryLabel: 'Body Care',
    price: 1650,
    compareAtPrice: 2100,
    images: [
      'https://images.unsplash.com/photo-1608248597359-59754f9a0c71?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1571781926291-c477ebfd024b?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Deeply nourishing botanical body moisturizer that melts instantly into the skin. Leaves a delicate warm vanilla amber fragrance with zero greasy residue.',
    features: [
      'Cold-pressed Moroccan Argan oil & raw shea butter',
      '48-hour continuous skin moisture retention',
      'Sulfate-free, paraben-free and cruelty-free',
      'Pump dispenser with travel lock mechanism'
    ],
    availability: 'in_stock',
    availabilityNote: 'Sourced from verified skincare distributor in Karachi.',
    estimatedDelivery: '2-4 business days',
    variants: [
      { name: 'Volume', options: ['250ml Pump Bottle', '400ml Family Size'] }
    ],
    featured: true,
    isPopular: true,
    sku: 'ZM-BDY-001'
  },
  {
    id: 'zm-bdy-02',
    slug: 'botanical-exfoliating-coffee-sugar-scrub',
    name: 'Roasted Arabica & Sweet Almond Body Scrub',
    category: 'body-care',
    categoryLabel: 'Body Care',
    price: 1450,
    compareAtPrice: 1900,
    images: [
      'https://images.unsplash.com/photo-1567928804448-4a0fb576ef60?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1556228722-d0b71f37e408?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Gentle exfoliating body polish with micro-ground Arabica coffee beans and brown sugar crystals. Buffs away dry skin and improves circulation.',
    features: [
      'Fine natural Arabica granules with sweet almond oil',
      'Targets rough elbows, knees, and strawberry legs',
      'Invigorating warm coffee fragrance',
      'Recyclable amber jar'
    ],
    availability: 'in_stock',
    availabilityNote: 'Supplier fulfillment batch ready for dispatch.',
    estimatedDelivery: '3-4 business days',
    variants: [
      { name: 'Size', options: ['200g Jar', '350g Deluxe Tub'] }
    ],
    sku: 'ZM-BDY-002'
  },
  {
    id: 'zm-bdy-03',
    slug: 'calming-lavender-eucalyptus-body-wash',
    name: 'Aromatherapy Calming Lavender Body Wash',
    category: 'body-care',
    categoryLabel: 'Body Care',
    price: 1250,
    compareAtPrice: 1600,
    images: [
      'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Luxurious lathering shower gel with essential oils of French lavender and crushed eucalyptus. Transforms your shower into an evening spa ritual.',
    features: [
      'pH balanced 5.5 skin-friendly formula',
      'Pure therapeutic-grade essential oil aroma',
      'Enriched with aloe vera juice to soothe inflammation',
      'Gentle on daily sensitive skin'
    ],
    availability: 'in_stock',
    availabilityNote: 'Supplier batch available.',
    estimatedDelivery: '2-4 business days',
    variants: [
      { name: 'Volume', options: ['300ml Bottle', '500ml Refill Pack'] }
    ],
    isNew: true,
    sku: 'ZM-BDY-003'
  },

  // --- ACCESSORIES ---
  {
    id: 'zm-acc-01',
    slug: 'herringbone-gold-plated-snake-chain',
    name: '18K Gold Plated Herringbone Flat Chain',
    category: 'accessories',
    categoryLabel: 'Accessories',
    price: 1950,
    compareAtPrice: 2600,
    images: [
      'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Timeless fluid herringbone chain necklace with high-polish mirror finish. Resistant to tarnish and designed to be worn alone or layered.',
    features: [
      'Triple-layer 18K gold electroplating over hypoallergenic steel',
      'Water and sweat resistant for daily wear',
      'Length: 42cm with 5cm adjustable extension link',
      'Packaged in Zavello Market velvet gift pouch'
    ],
    availability: 'in_stock',
    availabilityNote: 'Jewelry supplier stock verified in Lahore hub.',
    estimatedDelivery: '2-4 business days',
    variants: [
      { name: 'Finish', options: ['18K Yellow Gold', 'Polished Silver Chrome'] },
      { name: 'Width', options: ['3mm Slim Delicate', '5mm Statement Classic'] }
    ],
    featured: true,
    isPopular: true,
    sku: 'ZM-ACC-001'
  },
  {
    id: 'zm-acc-02',
    slug: 'structured-vegan-leather-tote',
    name: 'Structured Everyday Vegan Leather Tote',
    category: 'accessories',
    categoryLabel: 'Accessories',
    price: 3450,
    compareAtPrice: 4200,
    images: [
      'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1590874103328-eac38a683ce7?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Spacious, water-resistant everyday tote bag tailored for professionals and university students. Accommodates up to a 14-inch laptop with dedicated compartments.',
    features: [
      'Scratch-resistant textured PU leather',
      'Secure zip closure with gold-tone hardware',
      'Interior padded laptop sleeve + zip security pocket',
      'Comfortable dual shoulder drop straps'
    ],
    availability: 'in_stock',
    availabilityNote: 'Handbag workshop inventory confirmed.',
    estimatedDelivery: '3-4 business days',
    variants: [
      { name: 'Color', options: ['Warm Tan', 'Espresso Black', 'Stone Greige'] }
    ],
    featured: true,
    sku: 'ZM-ACC-002'
  },
  {
    id: 'zm-acc-03',
    slug: 'vintage-round-polarized-sunglasses',
    name: 'Retro Round UV400 Polarized Sunglasses',
    category: 'accessories',
    categoryLabel: 'Accessories',
    price: 1650,
    compareAtPrice: 2200,
    images: [
      'https://images.unsplash.com/photo-1511499767150-a48a237f0083?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1572635196237-14b3f281503f?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Chic vintage-inspired sunglasses featuring high-clarity polarized lenses with 100% UV400 protection against intense Pakistani sunshine.',
    features: [
      'UV400 cat-3 polarized glare reduction',
      'Lightweight metal-acetate hybrid frame',
      'Silicone soft nose pads for maximum comfort',
      'Includes microfiber travel pouch and cleaning cloth'
    ],
    availability: 'in_stock',
    availabilityNote: 'Supplier partner stock available.',
    estimatedDelivery: '2-4 business days',
    variants: [
      { name: 'Frame / Lens', options: ['Tortoise Shell / Warm Brown', 'Matte Black / Smoke Grey', 'Gold Metal / Bottle Green'] }
    ],
    isNew: true,
    sku: 'ZM-ACC-003'
  },

  // --- LIFESTYLE ---
  {
    id: 'zm-lfs-01',
    slug: 'amber-sandalwood-soy-candle',
    name: 'Artisan Amber & Sandalwood Soy Candle',
    category: 'lifestyle',
    categoryLabel: 'Lifestyle',
    price: 1850,
    compareAtPrice: 2400,
    images: [
      'https://images.unsplash.com/photo-1603006905003-be475563bc59?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1572726729437-3732efed3f8a?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Hand-poured 100% soy wax candle in an amber glass jar. Offers a rich, calming aroma of warm amber, Kashmiri sandalwood, and light vanilla.',
    features: [
      'Lead-free natural cotton double wick',
      '50+ hours clean burning time without black soot',
      'Non-toxic phthalate-free fragrance oils',
      'Reusable apothecary jar with seal lid'
    ],
    availability: 'in_stock',
    availabilityNote: 'Handcrafted in limited batches by lifestyle partner.',
    estimatedDelivery: '3-4 business days',
    variants: [
      { name: 'Scent', options: ['Amber & Sandalwood', 'White Tea & Jasmine', 'Wild Fig & Cedar'] }
    ],
    featured: true,
    isPopular: true,
    sku: 'ZM-LFS-001'
  },
  {
    id: 'zm-lfs-02',
    slug: 'pure-mulberry-silk-sleep-mask-set',
    name: 'Pure Mulberry Silk Eye Mask & Scrunchie Set',
    category: 'lifestyle',
    categoryLabel: 'Lifestyle',
    price: 1550,
    compareAtPrice: 2000,
    images: [
      'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'High-grade 22 momme silk eye mask with matching hair scrunchie. Protects delicate eye skin from friction, prevents lash breakage, and blocks 100% of light.',
    features: [
      'Grade 6A 22 Momme natural mulberry silk',
      'Soft elasticated head strap that does not tug hair',
      'Blocks ambient light for restorative deep sleep',
      'Includes matching silk scrunchie & travel bag'
    ],
    availability: 'in_stock',
    availabilityNote: 'Stock verified with lifestyle supplier.',
    estimatedDelivery: '2-4 business days',
    variants: [
      { name: 'Color', options: ['Champagne Pearl', 'Rose Gold Pink', 'Obsidian Black'] }
    ],
    isNew: true,
    sku: 'ZM-LFS-002'
  },
  {
    id: 'zm-lfs-03',
    slug: 'fluted-ceramic-nordic-vase',
    name: 'Aesthetic Fluted Ceramic Nordic Vase',
    category: 'lifestyle',
    categoryLabel: 'Lifestyle',
    price: 2450,
    compareAtPrice: 3100,
    images: [
      'https://images.unsplash.com/photo-1578749556568-bc2c40e68b61?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1612196808214-b8e1d6145a8c?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Contemporary ribbed ceramic decorative vase with matte tactile glaze. Elegant centerpiece for dry botanicals, pampas grass, or fresh floral stems.',
    features: [
      'Heavyweight ceramic stoneware with matte sand finish',
      'Waterproof interior for live fresh flowers',
      'Protective non-scratch base pads',
      'Height: 22cm, Diameter: 11cm'
    ],
    availability: 'in_stock',
    availabilityNote: 'Fragile item; packed with multi-layer bubble wrap by supplier.',
    estimatedDelivery: '3-5 business days',
    variants: [
      { name: 'Color', options: ['Warm Cream Ivory', 'Terracotta Blush', 'Charcoal Slate'] }
    ],
    sku: 'ZM-LFS-003'
  }
];

export const CATEGORIES_CONFIG = [
  { id: 'fashion' as const, name: 'Fashion', desc: 'Pret, co-ords, linen & seasonal apparel', count: 3, icon: 'Shirt' },
  { id: 'beauty' as const, name: 'Beauty & Cosmetics', desc: 'Lip velvet, serums, primers & eye makeup', count: 3, icon: 'Sparkles' },
  { id: 'body-care' as const, name: 'Body Care', desc: 'Argan lotions, scrubs & botanical washes', count: 3, icon: 'HeartHandshake' },
  { id: 'accessories' as const, name: 'Accessories', desc: '18K chains, everyday totes & sunglasses', count: 3, icon: 'ShoppingBag' },
  { id: 'lifestyle' as const, name: 'Lifestyle', desc: 'Soy candles, mulberry silk & aesthetic decor', count: 3, icon: 'Flame' },
];
