import { CartItem, CustomerInfo } from '../types';
import { formatPKR } from '../utils/currency';

export const ZAVELLO_WHATSAPP_NUMBER = '923259380039'; // +92 325 9380039 formatted for wa.me
export const ZAVELLO_WHATSAPP_DISPLAY = '+92 325 9380039';
export const ZAVELLO_EMAIL = 'Marketzavello@gmail.com';
export const ZAVELLO_STORE_URL = 'https://zavellomarket.store';

/**
 * Builds a clear, readable text message for WhatsApp order placement.
 */
export function buildWhatsAppOrderMessage(
  provisionalId: string,
  items: CartItem[],
  subtotal: number,
  shippingFee: number,
  total: number,
  customer: CustomerInfo
): string {
  const lineItemsText = items
    .map((item, index) => {
      const variantDetails = Object.entries(item.selectedVariants)
        .map(([key, value]) => `${key}: ${value}`)
        .join(', ');
      const variantStr = variantDetails ? ` (${variantDetails})` : '';
      return `${index + 1}. *${item.product.name}*${variantStr}\n   Qty: ${item.quantity} × ${formatPKR(item.unitPrice)} = *${formatPKR(item.quantity * item.unitPrice)}*`;
    })
    .join('\n\n');

  const shippingText = shippingFee === 0 
    ? 'FREE (Nationwide Promo over Rs. 3,000)' 
    : `${formatPKR(shippingFee)} (Standard Nationwide Delivery)`;

  const paymentText = customer.paymentMethod === 'cash_on_delivery'
    ? 'Cash on Delivery (COD) [Subject to confirmation]'
    : 'Bank Transfer / Online Enquiry [Subject to confirmation]';

  return `*🛍️ NEW ORDER REQUEST — ZAVELLO MARKET*
Provisional Ref: #${provisionalId}
Website: ${ZAVELLO_STORE_URL}

*👤 CUSTOMER DETAILS:*
• Name: ${customer.fullName}
• Phone: ${customer.phone}
• City: ${customer.city}
• Delivery Address: ${customer.address}
${customer.notes ? `• Order Notes: ${customer.notes}\n` : ''}
*📦 ORDER ITEMS:*
${lineItemsText}

*💰 PAYMENT & TOTALS:*
• Items Subtotal: ${formatPKR(subtotal)}
• Delivery Fee: ${shippingText}
• *Estimated Total: ${formatPKR(total)}*
• Payment Preference: ${paymentText}

*ℹ️ NOTE FOR ZAVELLO TEAM:*
Customer is requesting delivery across Pakistan. Please verify item availability from suppliers and confirm tracking & delivery schedule with me.`;
}

/**
 * Builds a direct product enquiry WhatsApp message.
 */
export function buildProductEnquiryMessage(
  productName: string,
  price: number,
  selectedVariants?: Record<string, string>
): string {
  const variantStr = selectedVariants && Object.keys(selectedVariants).length > 0
    ? `\nPreferred options: ` + Object.entries(selectedVariants).map(([k, v]) => `${k}: ${v}`).join(', ')
    : '';

  return `Hello Zavello Market! 👋
I am inquiring about the following product from your store:

*${productName}*
Price: ${formatPKR(price)}${variantStr}

Could you please confirm availability, delivery timeline, and Cash on Delivery to my city? Thank you!`;
}

/**
 * Generates the wa.me link.
 */
export function getWhatsAppUrl(messageText: string): string {
  const encoded = encodeURIComponent(messageText);
  return `https://wa.me/${ZAVELLO_WHATSAPP_NUMBER}?text=${encoded}`;
}
