import { CartItem, CustomerInfo, OrderSubmission } from '../types';

const CART_STORAGE_KEY = 'zavello_market_cart_v1';
const WISHLIST_STORAGE_KEY = 'zavello_market_wishlist_v1';
const CUSTOMER_STORAGE_KEY = 'zavello_market_customer_v1';
const LAST_ORDER_STORAGE_KEY = 'zavello_market_last_order_v1';

export const storageService = {
  getCart(): CartItem[] {
    try {
      const data = localStorage.getItem(CART_STORAGE_KEY);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  saveCart(items: CartItem[]): void {
    try {
      localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(items));
    } catch (e) {
      console.warn('Failed to save cart to localStorage', e);
    }
  },

  getWishlist(): string[] {
    try {
      const data = localStorage.getItem(WISHLIST_STORAGE_KEY);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  saveWishlist(ids: string[]): void {
    try {
      localStorage.setItem(WISHLIST_STORAGE_KEY, JSON.stringify(ids));
    } catch (e) {
      console.warn('Failed to save wishlist to localStorage', e);
    }
  },

  getSavedCustomer(): Partial<CustomerInfo> | null {
    try {
      const data = localStorage.getItem(CUSTOMER_STORAGE_KEY);
      return data ? JSON.parse(data) : null;
    } catch {
      return null;
    }
  },

  saveCustomer(customer: CustomerInfo): void {
    try {
      localStorage.setItem(CUSTOMER_STORAGE_KEY, JSON.stringify(customer));
    } catch (e) {
      console.warn('Failed to save customer to localStorage', e);
    }
  },

  getLastOrder(): OrderSubmission | null {
    try {
      const data = localStorage.getItem(LAST_ORDER_STORAGE_KEY);
      return data ? JSON.parse(data) : null;
    } catch {
      return null;
    }
  },

  saveLastOrder(order: OrderSubmission): void {
    try {
      localStorage.setItem(LAST_ORDER_STORAGE_KEY, JSON.stringify(order));
    } catch (e) {
      console.warn('Failed to save last order to localStorage', e);
    }
  }
};
