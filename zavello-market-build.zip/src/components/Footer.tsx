import React from 'react';
import { 
  Phone, 
  Mail, 
  Globe, 
  ShieldCheck, 
  Truck, 
  HelpCircle, 
  Smartphone,
  ExternalLink,
  MessageCircle
} from 'lucide-react';
import { ActiveScreen, PolicyTab, ProductCategory } from '../types';
import { 
  ZAVELLO_EMAIL, 
  ZAVELLO_STORE_URL, 
  ZAVELLO_WHATSAPP_DISPLAY, 
  getWhatsAppUrl 
} from '../services/whatsapp';

interface FooterProps {
  setActiveScreen: (screen: ActiveScreen) => void;
  setSelectedCategory: (cat: ProductCategory | 'all') => void;
  setSelectedPolicyTab: (tab: PolicyTab) => void;
  onOpenAndroidModal: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  setActiveScreen,
  setSelectedCategory,
  setSelectedPolicyTab,
  onOpenAndroidModal
}) => {
  const goToPolicy = (tab: PolicyTab) => {
    setSelectedPolicyTab(tab);
    setActiveScreen('policies');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const goToCategory = (category: ProductCategory) => {
    setSelectedCategory(category);
    setActiveScreen('shop');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-stone-900 text-stone-300 pt-12 pb-24 lg:pb-12 border-t border-stone-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Trust Pillars Banner */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 pb-12 border-b border-stone-800">
          <div className="flex items-start gap-3">
            <div className="p-2.5 rounded-lg bg-stone-800 text-amber-400 shrink-0">
              <Truck size={20} />
            </div>
            <div>
              <h4 className="text-xs sm:text-sm font-semibold text-white">Nationwide Pakistan Delivery</h4>
              <p className="text-[11px] text-stone-400 mt-0.5">Reliable dispatch to all major cities & towns across Pakistan.</p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="p-2.5 rounded-lg bg-stone-800 text-emerald-400 shrink-0">
              <ShieldCheck size={20} />
            </div>
            <div>
              <h4 className="text-xs sm:text-sm font-semibold text-white">Cash on Delivery (COD)</h4>
              <p className="text-[11px] text-stone-400 mt-0.5">Inspect & pay safely upon receiving your parcel at your doorstep.</p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="p-2.5 rounded-lg bg-stone-800 text-amber-400 shrink-0">
              <MessageCircle size={20} />
            </div>
            <div>
              <h4 className="text-xs sm:text-sm font-semibold text-white">Direct WhatsApp Support</h4>
              <p className="text-[11px] text-stone-400 mt-0.5">Prompt human assistance for order tracking and inquiries.</p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="p-2.5 rounded-lg bg-stone-800 text-sky-400 shrink-0">
              <HelpCircle size={20} />
            </div>
            <div>
              <h4 className="text-xs sm:text-sm font-semibold text-white">Transparent Sourcing</h4>
              <p className="text-[11px] text-stone-400 mt-0.5">Honest fulfillment notices and clear pricing in PKR.</p>
            </div>
          </div>
        </div>

        {/* Links Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 py-10">
          
          {/* Brand Info */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-2">
              <span className="font-serif-brand text-2xl font-extrabold tracking-wider text-white">
                ZAVELLO
              </span>
              <span className="text-xs uppercase tracking-widest px-2 py-0.5 bg-amber-500/20 text-amber-400 font-semibold rounded border border-amber-500/30">
                MARKET
              </span>
            </div>
            
            <p className="text-xs text-stone-400 leading-relaxed max-w-sm">
              Zavello Market is a contemporary online retail brand curating fashion, beauty, cosmetics, body care, accessories, and lifestyle essentials for customers across Pakistan.
            </p>

            {/* Business Contact details */}
            <div className="space-y-2 text-xs text-stone-300 pt-1">
              <a 
                href={getWhatsAppUrl("Hello Zavello Market!")}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2.5 hover:text-emerald-400 transition"
              >
                <Phone size={15} className="text-emerald-500" />
                <span>WhatsApp: {ZAVELLO_WHATSAPP_DISPLAY}</span>
              </a>

              <a 
                href={`mailto:${ZAVELLO_EMAIL}`}
                className="flex items-center gap-2.5 hover:text-amber-400 transition"
              >
                <Mail size={15} className="text-amber-500" />
                <span>Email: {ZAVELLO_EMAIL}</span>
              </a>

              <a 
                href={ZAVELLO_STORE_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2.5 hover:text-white transition"
              >
                <Globe size={15} className="text-sky-400" />
                <span>Store: {ZAVELLO_STORE_URL}</span>
                <ExternalLink size={12} className="opacity-60" />
              </a>
            </div>
          </div>

          {/* Categories */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-white mb-3">
              Shop Categories
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button 
                  onClick={() => goToCategory('fashion')}
                  className="hover:text-white transition text-stone-400"
                >
                  Fashion & Apparel
                </button>
              </li>
              <li>
                <button 
                  onClick={() => goToCategory('beauty')}
                  className="hover:text-white transition text-stone-400"
                >
                  Beauty & Cosmetics
                </button>
              </li>
              <li>
                <button 
                  onClick={() => goToCategory('body-care')}
                  className="hover:text-white transition text-stone-400"
                >
                  Body Care
                </button>
              </li>
              <li>
                <button 
                  onClick={() => goToCategory('accessories')}
                  className="hover:text-white transition text-stone-400"
                >
                  Accessories & Bags
                </button>
              </li>
              <li>
                <button 
                  onClick={() => goToCategory('lifestyle')}
                  className="hover:text-white transition text-stone-400"
                >
                  Lifestyle & Living
                </button>
              </li>
            </ul>
          </div>

          {/* Customer Service & Policies */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-white mb-3">
              Help & Policies
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button 
                  onClick={() => goToPolicy('shipping')}
                  className="hover:text-white transition text-stone-400"
                >
                  Shipping & Delivery
                </button>
              </li>
              <li>
                <button 
                  onClick={() => goToPolicy('returns')}
                  className="hover:text-white transition text-stone-400"
                >
                  Returns & Exchange Policy
                </button>
              </li>
              <li>
                <button 
                  onClick={() => goToPolicy('faq')}
                  className="hover:text-white transition text-stone-400"
                >
                  Frequently Asked Questions
                </button>
              </li>
              <li>
                <button 
                  onClick={() => goToPolicy('privacy')}
                  className="hover:text-white transition text-stone-400"
                >
                  Privacy Policy (Draft)
                </button>
              </li>
              <li>
                <button 
                  onClick={() => goToPolicy('terms')}
                  className="hover:text-white transition text-stone-400"
                >
                  Terms & Conditions
                </button>
              </li>
            </ul>
          </div>

          {/* Quick Info & Android Status */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-white mb-3">
              Application & App
            </h4>
            <div className="space-y-3">
              <p className="text-xs text-stone-400 leading-relaxed">
                Experience Zavello Market with instant WhatsApp checkout and offline cart persistence.
              </p>
              <button
                onClick={onOpenAndroidModal}
                className="w-full flex items-center justify-center gap-2 bg-stone-800 hover:bg-stone-700 text-stone-200 border border-stone-700 px-3 py-2 rounded-lg text-xs font-medium transition"
              >
                <Smartphone size={14} className="text-amber-400" />
                <span>Android App Roadmap</span>
              </button>
              <div className="text-[11px] text-stone-500">
                Primary Market: Pakistan (PKR)<br />
                Payments: Cash on Delivery
              </div>
            </div>
          </div>

        </div>

        {/* Bottom Bar & Honest Fulfillment Disclosure */}
        <div className="border-t border-stone-800 pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-stone-500">
          <p>
            © {new Date().getFullYear()} Zavello Market (zavellomarket.store). All rights reserved.
          </p>
          <p className="text-center sm:text-right max-w-md">
            *Supplier Fulfillment Disclosure: Products may be dispatched directly through vetted suppliers in Pakistan. Stock and courier timelines are verified upon WhatsApp submission.
          </p>
        </div>

      </div>
    </footer>
  );
};
