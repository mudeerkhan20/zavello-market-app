import React, { useState } from 'react';
import { 
  ShoppingBag, 
  Heart, 
  Search, 
  Menu, 
  X, 
  MessageCircle, 
  Phone, 
  Sparkles,
  Smartphone,
  ExternalLink
} from 'lucide-react';
import { ActiveScreen, ProductCategory } from '../types';
import { ZAVELLO_WHATSAPP_DISPLAY, getWhatsAppUrl } from '../services/whatsapp';

interface NavbarProps {
  activeScreen: ActiveScreen;
  setActiveScreen: (screen: ActiveScreen) => void;
  selectedCategory: ProductCategory | 'all';
  setSelectedCategory: (cat: ProductCategory | 'all') => void;
  cartCount: number;
  wishlistCount: number;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  onOpenCartDrawer: () => void;
  onOpenAndroidModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeScreen,
  setActiveScreen,
  setSelectedCategory,
  cartCount,
  wishlistCount,
  searchQuery,
  setSearchQuery,
  onOpenCartDrawer,
  onOpenAndroidModal
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showSearchInput, setShowSearchInput] = useState(false);

  const navigateTo = (screen: ActiveScreen, category?: ProductCategory | 'all') => {
    if (category) {
      setSelectedCategory(category);
    }
    setActiveScreen(screen);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setActiveScreen('shop');
      setShowSearchInput(false);
      setMobileMenuOpen(false);
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-stone-200 transition-all">
      {/* Top Announcement Bar */}
      <div className="bg-stone-900 text-stone-100 text-xs py-2 px-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2 overflow-hidden text-ellipsis whitespace-nowrap">
            <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span className="font-medium tracking-wide">
              Free Nationwide Delivery on orders over Rs. 3,000 | Cash on Delivery Available
            </span>
          </div>
          <div className="hidden md:flex items-center gap-4 text-stone-300 text-xs">
            <a 
              href={getWhatsAppUrl("Hello Zavello Market! I have an inquiry.")} 
              target="_blank" 
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 hover:text-emerald-400 transition"
            >
              <Phone size={12} />
              <span>{ZAVELLO_WHATSAPP_DISPLAY}</span>
            </a>
            <button
              onClick={onOpenAndroidModal}
              className="flex items-center gap-1 text-amber-300 hover:text-amber-200 transition font-medium"
            >
              <Smartphone size={13} />
              <span>Android Ready</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20 gap-4">
          
          {/* Mobile menu trigger */}
          <div className="flex items-center lg:hidden">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 -ml-2 text-stone-700 hover:text-stone-900 focus:outline-none"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>

          {/* Brand Logo & Name */}
          <div className="flex items-center">
            <button 
              onClick={() => navigateTo('home')}
              className="text-left group flex flex-col focus:outline-none"
            >
              <div className="flex items-center gap-1.5">
                <span className="font-serif-brand text-2xl sm:text-3xl font-extrabold tracking-wider text-stone-900 group-hover:text-stone-700 transition">
                  ZAVELLO
                </span>
                <span className="text-xs uppercase tracking-widest px-1.5 py-0.5 bg-stone-900 text-stone-100 font-semibold rounded">
                  MARKET
                </span>
              </div>
              <span className="text-[10px] tracking-[0.25em] uppercase text-stone-500 font-medium -mt-1 hidden sm:block">
                Pakistan • Online Retail
              </span>
            </button>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-7 text-sm font-medium text-stone-700">
            <button
              onClick={() => navigateTo('home')}
              className={`hover:text-stone-950 transition ${activeScreen === 'home' ? 'text-stone-950 font-semibold border-b-2 border-stone-900 pb-0.5' : ''}`}
            >
              Home
            </button>
            <button
              onClick={() => navigateTo('shop', 'all')}
              className={`hover:text-stone-950 transition ${activeScreen === 'shop' ? 'text-stone-950 font-semibold border-b-2 border-stone-900 pb-0.5' : ''}`}
            >
              Shop All
            </button>
            <button
              onClick={() => navigateTo('shop', 'fashion')}
              className="hover:text-stone-950 transition"
            >
              Fashion
            </button>
            <button
              onClick={() => navigateTo('shop', 'beauty')}
              className="hover:text-stone-950 transition"
            >
              Beauty
            </button>
            <button
              onClick={() => navigateTo('shop', 'body-care')}
              className="hover:text-stone-950 transition"
            >
              Body Care
            </button>
            <button
              onClick={() => navigateTo('shop', 'accessories')}
              className="hover:text-stone-950 transition"
            >
              Accessories
            </button>
            <button
              onClick={() => navigateTo('shop', 'lifestyle')}
              className="hover:text-stone-950 transition"
            >
              Lifestyle
            </button>
            <button
              onClick={() => navigateTo('about')}
              className={`hover:text-stone-950 transition ${activeScreen === 'about' ? 'text-stone-950 font-semibold' : ''}`}
            >
              About
            </button>
          </nav>

          {/* Right Action Icons & Search */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Desktop Search Bar */}
            <form onSubmit={handleSearchSubmit} className="hidden md:flex items-center relative">
              <input
                type="text"
                placeholder="Search fashion, skincare, accessories..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-56 lg:w-64 pl-9 pr-3 py-1.5 text-xs bg-stone-100 hover:bg-stone-50 focus:bg-white border border-stone-200 rounded-full focus:outline-none focus:ring-1 focus:ring-stone-400 focus:w-72 transition-all"
              />
              <Search size={14} className="absolute left-3 text-stone-400 pointer-events-none" />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2.5 text-stone-400 hover:text-stone-600"
                >
                  <X size={13} />
                </button>
              )}
            </form>

            {/* Mobile search toggle */}
            <button
              type="button"
              onClick={() => setShowSearchInput(!showSearchInput)}
              className="md:hidden p-2 text-stone-700 hover:text-stone-900"
              aria-label="Search"
            >
              <Search size={20} />
            </button>

            {/* Wishlist Icon */}
            <button
              onClick={() => navigateTo('wishlist')}
              className="relative p-2 text-stone-700 hover:text-stone-900 transition"
              aria-label="Wishlist"
              title="View Wishlist"
            >
              <Heart size={21} className={wishlistCount > 0 ? "fill-rose-500 text-rose-500" : ""} />
              {wishlistCount > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 bg-stone-900 text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                  {wishlistCount}
                </span>
              )}
            </button>

            {/* Cart Icon / Drawer Button */}
            <button
              onClick={onOpenCartDrawer}
              className="relative p-2 text-stone-700 hover:text-stone-900 transition flex items-center gap-1.5"
              aria-label="Shopping Cart"
              title="Shopping Cart"
            >
              <ShoppingBag size={21} />
              {cartCount > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 bg-amber-600 text-white text-[10px] font-bold rounded-full flex items-center justify-center animate-bounce">
                  {cartCount}
                </span>
              )}
            </button>

            {/* WhatsApp Quick Chat */}
            <a
              href={getWhatsAppUrl("Hello Zavello Market! I'd like to ask a question.")}
              target="_blank"
              rel="noopener noreferrer"
              className="hidden sm:flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold px-3 py-2 rounded-full transition shadow-xs"
              title="Chat with Zavello Market on WhatsApp"
            >
              <MessageCircle size={15} />
              <span>WhatsApp</span>
            </a>
          </div>
        </div>

        {/* Mobile Search input expand */}
        {showSearchInput && (
          <div className="md:hidden pb-3 pt-1">
            <form onSubmit={handleSearchSubmit} className="relative">
              <input
                type="text"
                autoFocus
                placeholder="Search products in Pakistan..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-8 py-2 text-sm bg-stone-100 border border-stone-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-stone-400"
              />
              <Search size={16} className="absolute left-3 top-3 text-stone-400 pointer-events-none" />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-3 text-stone-400 hover:text-stone-600"
                >
                  <X size={15} />
                </button>
              )}
            </form>
          </div>
        )}
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-stone-200 bg-white px-4 pt-3 pb-6 shadow-xl animate-fadeIn">
          <div className="space-y-1">
            <button
              onClick={() => navigateTo('home')}
              className={`w-full text-left py-2.5 px-3 rounded-md text-sm font-medium ${activeScreen === 'home' ? 'bg-stone-100 text-stone-900 font-semibold' : 'text-stone-700'}`}
            >
              Home
            </button>
            <button
              onClick={() => navigateTo('shop', 'all')}
              className={`w-full text-left py-2.5 px-3 rounded-md text-sm font-medium ${activeScreen === 'shop' ? 'bg-stone-100 text-stone-900 font-semibold' : 'text-stone-700'}`}
            >
              Shop All Products
            </button>

            <div className="py-2">
              <p className="px-3 text-xs font-bold uppercase tracking-wider text-stone-400 mb-1">
                Categories
              </p>
              <button
                onClick={() => navigateTo('shop', 'fashion')}
                className="w-full text-left py-2 px-3 text-sm text-stone-600 hover:bg-stone-50 rounded"
              >
                👗 Fashion & Apparel
              </button>
              <button
                onClick={() => navigateTo('shop', 'beauty')}
                className="w-full text-left py-2 px-3 text-sm text-stone-600 hover:bg-stone-50 rounded"
              >
                💄 Beauty & Cosmetics
              </button>
              <button
                onClick={() => navigateTo('shop', 'body-care')}
                className="w-full text-left py-2 px-3 text-sm text-stone-600 hover:bg-stone-50 rounded"
              >
                🧴 Body Care
              </button>
              <button
                onClick={() => navigateTo('shop', 'accessories')}
                className="w-full text-left py-2 px-3 text-sm text-stone-600 hover:bg-stone-50 rounded"
              >
                👜 Accessories & Jewelry
              </button>
              <button
                onClick={() => navigateTo('shop', 'lifestyle')}
                className="w-full text-left py-2 px-3 text-sm text-stone-600 hover:bg-stone-50 rounded"
              >
                🕯️ Lifestyle & Home
              </button>
            </div>

            <div className="border-t border-stone-100 pt-2 space-y-1">
              <button
                onClick={() => navigateTo('about')}
                className="w-full text-left py-2 px-3 text-sm text-stone-700 hover:bg-stone-50 rounded"
              >
                About Zavello Market
              </button>
              <button
                onClick={() => navigateTo('contact')}
                className="w-full text-left py-2 px-3 text-sm text-stone-700 hover:bg-stone-50 rounded"
              >
                Contact Us
              </button>
              <button
                onClick={() => navigateTo('policies')}
                className="w-full text-left py-2 px-3 text-sm text-stone-700 hover:bg-stone-50 rounded"
              >
                Shipping & Policies
              </button>
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenAndroidModal();
                }}
                className="w-full text-left py-2 px-3 text-sm text-amber-700 bg-amber-50 rounded flex items-center justify-between"
              >
                <span className="flex items-center gap-1.5">
                  <Smartphone size={16} />
                  Android Application Guide
                </span>
                <span className="text-[10px] bg-amber-200 text-amber-900 px-1.5 py-0.5 rounded font-bold">INFO</span>
              </button>
            </div>

            <div className="pt-4">
              <a
                href={getWhatsAppUrl("Hello Zavello Market! I'd like to place an inquiry.")}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-medium py-2.5 rounded-lg transition"
              >
                <MessageCircle size={18} />
                <span>Chat on WhatsApp (+92 325 9380039)</span>
              </a>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
