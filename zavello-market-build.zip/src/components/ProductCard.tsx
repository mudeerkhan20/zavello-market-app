import React, { useState } from 'react';
import { Heart, ShoppingBag, Eye, Check } from 'lucide-react';
import { Product } from '../types';
import { formatPKR } from '../utils/currency';

interface ProductCardProps {
  product: Product;
  onSelectProduct: (product: Product) => void;
  onQuickAddToCart: (product: Product) => void;
  isWishlisted: boolean;
  onToggleWishlist: (productId: string) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onSelectProduct,
  onQuickAddToCart,
  isWishlisted,
  onToggleWishlist
}) => {
  const [imageError, setImageError] = useState(false);
  const [addedAnimation, setAddedAnimation] = useState(false);

  const discountPercent = product.compareAtPrice 
    ? Math.round(((product.compareAtPrice - product.price) / product.compareAtPrice) * 100)
    : 0;

  const handleQuickAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    onQuickAddToCart(product);
    setAddedAnimation(true);
    setTimeout(() => setAddedAnimation(false), 1200);
  };

  const handleWishlistToggle = (e: React.MouseEvent) => {
    e.stopPropagation();
    onToggleWishlist(product.id);
  };

  return (
    <div 
      onClick={() => onSelectProduct(product)}
      className="group flex flex-col bg-white rounded-xl border border-stone-200/80 overflow-hidden hover:shadow-lg hover:border-stone-300 transition-all duration-300 cursor-pointer relative"
    >
      {/* Product Image Area */}
      <div className="relative aspect-square sm:aspect-[4/5] bg-stone-100 overflow-hidden">
        {imageError ? (
          <div className="w-full h-full flex flex-col items-center justify-center p-4 text-stone-400 bg-stone-100 text-center">
            <ShoppingBag size={32} className="stroke-1 mb-2 opacity-50" />
            <span className="text-xs font-medium text-stone-500">{product.name}</span>
            <span className="text-[10px] text-stone-400 mt-1">Image preview</span>
          </div>
        ) : (
          <img
            src={product.images[0]}
            alt={product.name}
            onError={() => setImageError(true)}
            className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500 ease-out"
            loading="lazy"
          />
        )}

        {/* Badges Overlay */}
        <div className="absolute top-2.5 left-2.5 flex flex-col gap-1 items-start">
          {discountPercent > 0 && (
            <span className="bg-stone-900 text-stone-50 text-[10px] font-bold px-2 py-0.5 rounded shadow-xs tracking-wider uppercase">
              Save {discountPercent}%
            </span>
          )}
          {product.isNew && (
            <span className="bg-amber-600 text-white text-[10px] font-bold px-2 py-0.5 rounded shadow-xs tracking-wider uppercase">
              New
            </span>
          )}
        </div>

        {/* Wishlist Button */}
        <button
          type="button"
          onClick={handleWishlistToggle}
          className={`absolute top-2.5 right-2.5 p-2 rounded-full transition shadow-xs ${
            isWishlisted 
              ? 'bg-rose-50 text-rose-500' 
              : 'bg-white/80 backdrop-blur-xs text-stone-600 hover:text-rose-500 hover:bg-white'
          }`}
          aria-label={isWishlisted ? "Remove from Wishlist" : "Add to Wishlist"}
        >
          <Heart 
            size={16} 
            className={isWishlisted ? "fill-rose-500 text-rose-500" : ""} 
          />
        </button>

        {/* Desktop Quick View Overlay On Hover */}
        <div className="absolute inset-x-3 bottom-3 hidden sm:flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
          <button
            type="button"
            onClick={handleQuickAdd}
            className={`flex-1 py-2 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition shadow-sm ${
              addedAnimation 
                ? 'bg-emerald-600 text-white' 
                : 'bg-stone-900 hover:bg-stone-800 text-white'
            }`}
          >
            {addedAnimation ? (
              <>
                <Check size={14} />
                <span>Added!</span>
              </>
            ) : (
              <>
                <ShoppingBag size={14} />
                <span>Quick Add</span>
              </>
            )}
          </button>
          
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onSelectProduct(product);
            }}
            className="p-2 bg-white/90 hover:bg-white text-stone-800 rounded-lg text-xs font-semibold shadow-sm transition"
            title="View Details"
          >
            <Eye size={16} />
          </button>
        </div>
      </div>

      {/* Product Content Info */}
      <div className="p-3.5 sm:p-4 flex flex-col flex-1 justify-between">
        <div>
          <div className="flex items-center justify-between text-[11px] text-stone-500 mb-1">
            <span className="uppercase font-medium tracking-wider">{product.categoryLabel}</span>
            <span className="text-emerald-700 font-medium">Cash on Delivery</span>
          </div>

          <h3 className="font-semibold text-stone-900 text-sm line-clamp-1 group-hover:text-stone-700 transition">
            {product.name}
          </h3>

          <p className="text-xs text-stone-500 line-clamp-1 mt-0.5">
            {product.description}
          </p>
        </div>

        <div className="mt-3 pt-2.5 border-t border-stone-100 flex items-center justify-between">
          <div className="flex items-baseline gap-2">
            <span className="text-sm sm:text-base font-bold text-stone-900">
              {formatPKR(product.price)}
            </span>
            {product.compareAtPrice && (
              <span className="text-xs text-stone-400 line-through">
                {formatPKR(product.compareAtPrice)}
              </span>
            )}
          </div>

          {/* Mobile quick add button */}
          <button
            type="button"
            onClick={handleQuickAdd}
            className={`sm:hidden p-2 rounded-lg text-xs font-medium transition ${
              addedAnimation
                ? 'bg-emerald-600 text-white'
                : 'bg-stone-100 text-stone-800 hover:bg-stone-900 hover:text-white'
            }`}
            aria-label="Add to cart"
          >
            {addedAnimation ? <Check size={15} /> : <ShoppingBag size={15} />}
          </button>
        </div>

        {/* Honest fulfillment disclosure tag */}
        <div className="mt-2 text-[10px] text-stone-400 flex items-center gap-1">
          <span className="w-1.5 h-1.5 rounded-full bg-stone-300"></span>
          <span>Supplier Verified on WhatsApp</span>
        </div>
      </div>
    </div>
  );
};
