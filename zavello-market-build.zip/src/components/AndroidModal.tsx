import React from 'react';
import { X, Smartphone, Layers, CheckCircle, AlertTriangle, Terminal, Play, Download } from 'lucide-react';

interface AndroidModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AndroidModal: React.FC<AndroidModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] flex flex-col shadow-2xl border border-stone-200">
        
        {/* Header */}
        <div className="p-5 border-b border-stone-200 flex items-center justify-between bg-stone-50 rounded-t-2xl">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-stone-900 text-stone-100 rounded-lg">
              <Smartphone size={20} />
            </div>
            <div>
              <h3 className="font-bold text-stone-900 text-base sm:text-lg">
                Android Architecture & Google Play Readiness
              </h3>
              <p className="text-xs text-stone-500">
                Technical overview for Zavello Market mobile application
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-stone-400 hover:text-stone-700 hover:bg-stone-200/50 rounded-full transition"
            aria-label="Close"
          >
            <X size={20} />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-5 text-sm text-stone-700 leading-relaxed">
          
          {/* Status Box */}
          <div className="p-4 bg-amber-50/70 border border-amber-200/80 rounded-xl space-y-2">
            <div className="flex items-center gap-2 text-amber-900 font-semibold text-xs uppercase tracking-wider">
              <AlertTriangle size={15} className="text-amber-700" />
              <span>Current Environment Reality Check</span>
            </div>
            <p className="text-xs text-amber-950">
              This application is currently running as a <strong>Mobile-First React Single-Page Web Application (SPA)</strong> on Vite. It is fully responsive and touch-optimized for mobile viewports, but is <strong>not yet a compiled native Android APK or AAB bundle</strong>, as the browser development container does not run Android SDK or Gradle.
            </p>
          </div>

          {/* Section: How to convert to Native Android APK / Play Store */}
          <div>
            <h4 className="font-bold text-stone-900 text-sm flex items-center gap-2 mb-2">
              <Terminal size={16} className="text-stone-800" />
              <span>Step-by-Step Android Packaging (Capacitor Flow)</span>
            </h4>
            <div className="space-y-2 text-xs bg-stone-900 text-stone-200 p-4 rounded-xl font-mono overflow-x-auto">
              <p className="text-stone-400"># 1. Install Capacitor core and CLI in this project:</p>
              <p className="text-emerald-400">npm install @capacitor/core @capacitor/cli @capacitor/android</p>
              <p className="text-stone-400 mt-2"># 2. Initialize Capacitor with Zavello Market package ID:</p>
              <p className="text-emerald-400">npx cap init "Zavello Market" "com.zavellomarket.app"</p>
              <p className="text-stone-400 mt-2"># 3. Build the web distribution:</p>
              <p className="text-emerald-400">npm run build</p>
              <p className="text-stone-400 mt-2"># 4. Add Android native platform:</p>
              <p className="text-emerald-400">npx cap add android</p>
              <p className="text-stone-400 mt-2"># 5. Open Android Studio to build APK/AAB & sign:</p>
              <p className="text-emerald-400">npx cap open android</p>
            </div>
          </div>

          {/* Publishing on Google Play Store Requirements */}
          <div>
            <h4 className="font-bold text-stone-900 text-sm flex items-center gap-2 mb-2">
              <Play size={16} className="text-emerald-700" />
              <span>Google Play Publication Checklist for Zavello Market</span>
            </h4>
            <ul className="space-y-2 text-xs text-stone-600">
              <li className="flex items-start gap-2">
                <CheckCircle size={14} className="text-emerald-600 shrink-0 mt-0.5" />
                <span><strong>Google Play Console Developer Account:</strong> One-time $25 registration fee.</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle size={14} className="text-emerald-600 shrink-0 mt-0.5" />
                <span><strong>Keystore & App Signing:</strong> Generate a production upload key in Android Studio to sign the <code>.aab</code> (Android App Bundle).</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle size={14} className="text-emerald-600 shrink-0 mt-0.5" />
                <span><strong>Store Assets:</strong> High-resolution app icon (512x512px), feature graphic (1024x500px), and mobile screenshots.</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle size={14} className="text-emerald-600 shrink-0 mt-0.5" />
                <span><strong>Privacy Policy & Terms:</strong> Host the finalized draft policies at <code>https://zavellomarket.store/privacy</code>.</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle size={14} className="text-emerald-600 shrink-0 mt-0.5" />
                <span><strong>Target API Level:</strong> Target Android 14+ (API Level 34) as required by Google Play policies.</span>
              </li>
            </ul>
          </div>

          {/* Backend & Scalability Boundary */}
          <div className="border-t border-stone-200 pt-4">
            <h4 className="font-bold text-stone-900 text-sm flex items-center gap-2 mb-2">
              <Layers size={16} className="text-stone-800" />
              <span>Backend & Database Integration Roadmap</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-stone-600">
              <div className="p-3 bg-stone-50 rounded-lg border border-stone-200">
                <span className="font-bold text-stone-900 block mb-1">Phase 1: WhatsApp Retail (Active)</span>
                Zero-infrastructure prototype. Orders and inquiries routed safely via WhatsApp to +92 325 9380039.
              </div>
              <div className="p-3 bg-stone-50 rounded-lg border border-stone-200">
                <span className="font-bold text-stone-900 block mb-1">Phase 2: Database & Admin API</span>
                Cloud SQL (PostgreSQL) or Firebase Firestore for persistent catalog management, order history, and merchant inventory sync.
              </div>
            </div>
          </div>

        </div>

        {/* Footer */}
        <div className="p-4 border-t border-stone-200 bg-stone-50 rounded-b-2xl flex items-center justify-between gap-3">
          <a
            href="/zavello-market-source.zip"
            download="zavello-market-source.zip"
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition shadow-xs"
          >
            <Download size={15} />
            <span>Download Project ZIP</span>
          </a>
          <button
            onClick={onClose}
            className="px-5 py-2 bg-stone-900 hover:bg-stone-800 text-white rounded-lg text-xs font-semibold transition"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};
