import React from 'react';
import { Home, Compass, ShoppingBag, Heart, UserCheck } from 'lucide-react';
import { ActiveScreen } from '../types';

interface BottomNavProps {
  activeScreen: ActiveScreen;
  setActiveScreen: (screen: ActiveScreen) => void;
  cartCount: number;
  wishlistCount: number;
  onOpenCartDrawer: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeScreen,
  setActiveScreen,
  cartCount,
  wishlistCount,
  onOpenCartDrawer
}) => {
  const handleNav = (screen: ActiveScreen) => {
    setActiveScreen(screen);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-stone-200 shadow-lg pb-safe">
      <nav className="flex items-center justify-around h-14 px-2">
        {/* Home */}
        <button
          onClick={() => handleNav('home')}
          className={`flex flex-col items-center justify-center flex-1 py-1 transition ${
            activeScreen === 'home' ? 'text-stone-900 font-semibold' : 'text-stone-400 hover:text-stone-600'
          }`}
        >
          <Home size={19} className={activeScreen === 'home' ? 'stroke-[2.5]' : ''} />
          <span className="text-[10px] mt-0.5 tracking-tight">Home</span>
        </button>

        {/* Shop */}
        <button
          onClick={() => handleNav('shop')}
          className={`flex flex-col items-center justify-center flex-1 py-1 transition ${
            activeScreen === 'shop' ? 'text-stone-900 font-semibold' : 'text-stone-400 hover:text-stone-600'
          }`}
        >
          <Compass size={19} className={activeScreen === 'shop' ? 'stroke-[2.5]' : ''} />
          <span className="text-[10px] mt-0.5 tracking-tight">Shop</span>
        </button>

        {/* Wishlist */}
        <button
          onClick={() => handleNav('wishlist')}
          className={`relative flex flex-col items-center justify-center flex-1 py-1 transition ${
            activeScreen === 'wishlist' ? 'text-stone-900 font-semibold' : 'text-stone-400 hover:text-stone-600'
          }`}
        >
          <Heart 
            size={19} 
            className={activeScreen === 'wishlist' ? 'stroke-[2.5] fill-stone-900' : ''} 
          />
          {wishlistCount > 0 && (
            <span className="absolute top-0 right-4 w-3.5 h-3.5 bg-rose-500 text-white text-[9px] font-bold rounded-full flex items-center justify-center">
              {wishlistCount}
            </span>
          )}
          <span className="text-[10px] mt-0.5 tracking-tight">Wishlist</span>
        </button>

        {/* Bag / Cart */}
        <button
          onClick={onOpenCartDrawer}
          className={`relative flex flex-col items-center justify-center flex-1 py-1 transition ${
            activeScreen === 'cart' || activeScreen === 'checkout' ? 'text-stone-900 font-semibold' : 'text-stone-400 hover:text-stone-600'
          }`}
        >
          <ShoppingBag size={19} className={activeScreen === 'cart' ? 'stroke-[2.5]' : ''} />
          {cartCount > 0 && (
            <span className="absolute top-0 right-4 w-3.5 h-3.5 bg-amber-600 text-white text-[9px] font-bold rounded-full flex items-center justify-center">
              {cartCount}
            </span>
          )}
          <span className="text-[10px] mt-0.5 tracking-tight">Bag</span>
        </button>

        {/* About / Support */}
        <button
          onClick={() => handleNav('about')}
          className={`flex flex-col items-center justify-center flex-1 py-1 transition ${
            activeScreen === 'about' || activeScreen === 'contact' ? 'text-stone-900 font-semibold' : 'text-stone-400 hover:text-stone-600'
          }`}
        >
          <UserCheck size={19} className={activeScreen === 'about' ? 'stroke-[2.5]' : ''} />
          <span className="text-[10px] mt-0.5 tracking-tight">About</span>
        </button>
      </nav>
    </div>
  );
};
