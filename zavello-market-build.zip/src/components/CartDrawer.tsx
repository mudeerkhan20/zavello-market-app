import React from 'react';
import { X, Trash2, Plus, Minus, ShoppingBag, ArrowRight, Truck } from 'lucide-react';
import { CartItem } from '../types';
import { formatPKR, calculateShipping } from '../utils/currency';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (cartItemId: string, newQty: number) => void;
  onRemoveItem: (cartItemId: string) => void;
  onGoToCheckout: () => void;
  onGoToCartPage: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onGoToCheckout,
  onGoToCartPage
}) => {
  if (!isOpen) return null;

  const subtotal = items.reduce((sum, item) => sum + item.unitPrice * item.quantity, 0);
  const shippingFee = calculateShipping(subtotal);
  const total = subtotal + shippingFee;
  const freeShippingThreshold = 3000;
  const freeShippingProgress = Math.min(100, Math.round((subtotal / freeShippingThreshold) * 100));
  const amountNeededForFreeShipping = Math.max(0, freeShippingThreshold - subtotal);

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-stone-900/50 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-white shadow-2xl flex flex-col">
          {/* Header */}
          <div className="p-4 sm:p-5 border-b border-stone-200 flex items-center justify-between bg-stone-50/50">
            <div className="flex items-center gap-2">
              <ShoppingBag size={20} className="text-stone-800" />
              <h2 className="text-base sm:text-lg font-bold text-stone-900">
                Shopping Bag ({items.reduce((acc, i) => acc + i.quantity, 0)})
              </h2>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 rounded-full text-stone-400 hover:text-stone-700 hover:bg-stone-200/50 transition"
              aria-label="Close cart"
            >
              <X size={20} />
            </button>
          </div>

          {/* Free shipping banner */}
          <div className="bg-amber-50/80 border-b border-amber-100 p-3 text-xs text-amber-900">
            <div className="flex items-center gap-2 mb-1.5 font-medium">
              <Truck size={15} className="text-amber-700" />
              {amountNeededForFreeShipping > 0 ? (
                <span>
                  Add <strong className="font-bold">{formatPKR(amountNeededForFreeShipping)}</strong> more for <span className="font-bold text-emerald-800">FREE Delivery</span> in Pakistan!
                </span>
              ) : (
                <span className="text-emerald-800 font-bold">
                  🎉 You have qualified for FREE delivery nationwide!
                </span>
              )}
            </div>
            <div className="w-full bg-amber-200/60 rounded-full h-1.5 overflow-hidden">
              <div 
                className="bg-amber-600 h-1.5 rounded-full transition-all duration-300"
                style={{ width: `${freeShippingProgress}%` }}
              />
            </div>
          </div>

          {/* Cart Items List */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
            {items.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 text-stone-500">
                <div className="w-16 h-16 rounded-full bg-stone-100 flex items-center justify-center mb-3">
                  <ShoppingBag size={28} className="text-stone-400 stroke-1" />
                </div>
                <h3 className="text-base font-semibold text-stone-800">Your bag is empty</h3>
                <p className="text-xs text-stone-500 mt-1 max-w-xs">
                  Explore our curated fashion, beauty, and lifestyle essentials from Pakistan.
                </p>
                <button
                  onClick={onClose}
                  className="mt-5 px-5 py-2.5 bg-stone-900 hover:bg-stone-800 text-white rounded-lg text-xs font-semibold tracking-wide transition"
                >
                  Start Shopping
                </button>
              </div>
            ) : (
              items.map((item) => (
                <div 
                  key={item.id}
                  className="flex gap-3.5 pb-4 border-b border-stone-100 last:border-0"
                >
                  <img
                    src={item.product.images[0]}
                    alt={item.product.name}
                    className="w-18 h-22 object-cover rounded-lg bg-stone-100 shrink-0"
                  />
                  <div className="flex-1 flex flex-col justify-between min-w-0">
                    <div>
                      <div className="flex items-start justify-between gap-2">
                        <h4 className="text-xs sm:text-sm font-semibold text-stone-900 truncate">
                          {item.product.name}
                        </h4>
                        <button
                          onClick={() => onRemoveItem(item.id)}
                          className="text-stone-400 hover:text-rose-500 p-0.5 transition shrink-0"
                          title="Remove item"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>

                      {/* Selected Variants */}
                      {Object.keys(item.selectedVariants).length > 0 && (
                        <div className="flex flex-wrap gap-1 mt-1">
                          {Object.entries(item.selectedVariants).map(([key, val]) => (
                            <span 
                              key={key} 
                              className="text-[10px] bg-stone-100 text-stone-600 px-1.5 py-0.5 rounded font-medium"
                            >
                              {key}: {val}
                            </span>
                          ))}
                        </div>
                      )}

                      <div className="text-xs font-bold text-stone-900 mt-1">
                        {formatPKR(item.unitPrice)}
                      </div>
                    </div>

                    {/* Quantity Selector */}
                    <div className="flex items-center justify-between mt-2">
                      <div className="flex items-center border border-stone-200 rounded-md bg-stone-50">
                        <button
                          onClick={() => onUpdateQuantity(item.id, item.quantity - 1)}
                          className="p-1 hover:bg-stone-200/60 text-stone-600 transition rounded-l-md"
                          aria-label="Decrease quantity"
                        >
                          <Minus size={12} />
                        </button>
                        <span className="px-2.5 text-xs font-semibold text-stone-800">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => onUpdateQuantity(item.id, item.quantity + 1)}
                          className="p-1 hover:bg-stone-200/60 text-stone-600 transition rounded-r-md"
                          aria-label="Increase quantity"
                        >
                          <Plus size={12} />
                        </button>
                      </div>

                      <span className="text-xs font-semibold text-stone-900">
                        {formatPKR(item.unitPrice * item.quantity)}
                      </span>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Footer Summary & Checkout */}
          {items.length > 0 && (
            <div className="p-4 sm:p-5 border-t border-stone-200 bg-stone-50/70 space-y-3">
              <div className="space-y-1.5 text-xs">
                <div className="flex justify-between text-stone-600">
                  <span>Subtotal</span>
                  <span className="font-semibold text-stone-900">{formatPKR(subtotal)}</span>
                </div>
                <div className="flex justify-between text-stone-600">
                  <div className="flex items-center gap-1">
                    <span>Estimated Shipping</span>
                    <span className="text-[10px] text-stone-400">(Pakistan)</span>
                  </div>
                  <span className="font-semibold text-stone-900">
                    {shippingFee === 0 ? (
                      <span className="text-emerald-700 uppercase font-bold text-[11px]">Free</span>
                    ) : (
                      formatPKR(shippingFee)
                    )}
                  </span>
                </div>
                <div className="border-t border-stone-200 pt-2 flex justify-between text-sm sm:text-base font-bold text-stone-900">
                  <span>Estimated Total</span>
                  <span>{formatPKR(total)}</span>
                </div>
                <p className="text-[10px] text-stone-500 italic text-center pt-0.5">
                  Cash on Delivery available. Verified upon WhatsApp submission.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onGoToCartPage();
                  }}
                  className="py-2.5 px-3 border border-stone-300 hover:bg-stone-100 text-stone-800 rounded-lg text-xs font-semibold transition text-center"
                >
                  View Full Cart
                </button>
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onGoToCheckout();
                  }}
                  className="py-2.5 px-3 bg-stone-900 hover:bg-stone-800 text-white rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition text-center"
                >
                  <span>Checkout</span>
                  <ArrowRight size={14} />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
