export type ProductCategory = 
  | 'fashion' 
  | 'beauty' 
  | 'body-care' 
  | 'accessories' 
  | 'lifestyle';

export interface ProductVariant {
  name: string; // e.g. "Size", "Shade", "Volume"
  options: string[]; // e.g. ["Small", "Medium", "Large"]
}

export interface Product {
  id: string;
  slug: string;
  name: string;
  category: ProductCategory;
  categoryLabel: string;
  price: number; // in PKR
  compareAtPrice?: number; // original price for comparison
  images: string[];
  description: string;
  features?: string[];
  availability: 'in_stock' | 'supplier_order' | 'low_stock' | 'out_of_stock';
  availabilityNote: string;
  estimatedDelivery: string;
  variants?: ProductVariant[];
  featured?: boolean;
  isNew?: boolean;
  isPopular?: boolean;
  sku?: string;
  internalSupplierNotes?: string;
}

export interface CartItem {
  id: string; // composite key e.g. `${product.id}-${JSON.stringify(variants)}`
  productId: string;
  product: Product;
  selectedVariants: Record<string, string>;
  quantity: number;
  unitPrice: number;
}

export interface CustomerInfo {
  fullName: string;
  phone: string;
  city: string;
  address: string;
  notes?: string;
  paymentMethod: 'cash_on_delivery' | 'bank_transfer_enquiry';
}

export interface OrderSubmission {
  provisionalId: string; // clearly labeled as provisional/client-side reference
  items: CartItem[];
  subtotal: number;
  shippingFee: number;
  total: number;
  customer: CustomerInfo;
  createdAt: string;
  whatsappMessage: string;
  status: 'awaiting_confirmation';
}

export type ActiveScreen = 
  | 'home' 
  | 'shop' 
  | 'product-detail' 
  | 'cart' 
  | 'checkout' 
  | 'order-confirmation' 
  | 'wishlist' 
  | 'about' 
  | 'contact' 
  | 'policies';

export type PolicyTab = 
  | 'shipping' 
  | 'returns' 
  | 'privacy' 
  | 'terms' 
  | 'faq';
