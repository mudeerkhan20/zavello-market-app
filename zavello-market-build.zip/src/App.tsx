import React, { useState, useEffect } from 'react';
import { 
  ActiveScreen, 
  CartItem, 
  OrderSubmission, 
  PolicyTab, 
  Product, 
  ProductCategory 
} from './types';
import { SAMPLE_PRODUCTS } from './data/products';
import { storageService } from './services/storage';

// Components
import { Navbar } from './components/Navbar';
import { BottomNav } from './components/BottomNav';
import { CartDrawer } from './components/CartDrawer';
import { Footer } from './components/Footer';
import { AndroidModal } from './components/AndroidModal';

// Pages
import { HomePage } from './pages/HomePage';
import { ShopPage } from './pages/ShopPage';
import { ProductDetailPage } from './pages/ProductDetailPage';
import { CartPage } from './pages/CartPage';
import { CheckoutPage } from './pages/CheckoutPage';
import { OrderConfirmationPage } from './pages/OrderConfirmationPage';
import { WishlistPage } from './pages/WishlistPage';
import { AboutPage } from './pages/AboutPage';
import { ContactPage } from './pages/ContactPage';
import { PoliciesPage } from './pages/PoliciesPage';

export default function App() {
  const [activeScreen, setActiveScreen] = useState<ActiveScreen>('home');
  const [selectedCategory, setSelectedCategory] = useState<ProductCategory | 'all'>('all');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedPolicyTab, setSelectedPolicyTab] = useState<PolicyTab>('shipping');
  
  // Modals & Drawers
  const [isCartDrawerOpen, setIsCartDrawerOpen] = useState<boolean>(false);
  const [isAndroidModalOpen, setIsAndroidModalOpen] = useState<boolean>(false);

  // Cart & Wishlist state initialized from localStorage
  const [cartItems, setCartItems] = useState<CartItem[]>(() => storageService.getCart());
  const [wishlistIds, setWishlistIds] = useState<string[]>(() => storageService.getWishlist());
  const [currentOrder, setCurrentOrder] = useState<OrderSubmission | null>(() => storageService.getLastOrder());

  // Toast feedback state
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 2800);
  };

  // Sync cart to localStorage whenever it changes
  useEffect(() => {
    storageService.saveCart(cartItems);
  }, [cartItems]);

  // Sync wishlist to localStorage whenever it changes
  useEffect(() => {
    storageService.saveWishlist(wishlistIds);
  }, [wishlistIds]);

  // Handlers for cart
  const handleAddToCart = (product: Product, variants: Record<string, string> = {}, quantity: number = 1) => {
    const variantKey = Object.entries(variants).sort().map(([k, v]) => `${k}:${v}`).join('|');
    const compositeId = `${product.id}-${variantKey || 'default'}`;

    setCartItems(prev => {
      const existingIndex = prev.findIndex(item => item.id === compositeId);
      if (existingIndex > -1) {
        const updated = [...prev];
        updated[existingIndex] = {
          ...updated[existingIndex],
          quantity: updated[existingIndex].quantity + quantity
        };
        return updated;
      } else {
        const newItem: CartItem = {
          id: compositeId,
          productId: product.id,
          product,
          selectedVariants: variants,
          quantity,
          unitPrice: product.price
        };
        return [...prev, newItem];
      }
    });

    showToast(`Added ${quantity} × ${product.name} to your bag`);
  };

  const handleUpdateQuantity = (cartItemId: string, newQty: number) => {
    if (newQty <= 0) {
      handleRemoveFromCart(cartItemId);
      return;
    }
    setCartItems(prev =>
      prev.map(item => item.id === cartItemId ? { ...item, quantity: newQty } : item)
    );
  };

  const handleRemoveFromCart = (cartItemId: string) => {
    setCartItems(prev => prev.filter(item => item.id !== cartItemId));
    showToast('Item removed from bag');
  };

  const handleClearCart = () => {
    setCartItems([]);
    showToast('Shopping bag cleared');
  };

  // Wishlist handler
  const handleToggleWishlist = (productId: string) => {
    setWishlistIds(prev => {
      if (prev.includes(productId)) {
        showToast('Removed from wishlist');
        return prev.filter(id => id !== productId);
      } else {
        showToast('Saved to wishlist');
        return [...prev, productId];
      }
    });
  };

  // Navigation helpers
  const handleSelectProduct = (product: Product) => {
    setSelectedProduct(product);
    setActiveScreen('product-detail');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOrderSubmitted = (order: OrderSubmission) => {
    setCurrentOrder(order);
    // Clear cart after order is prepared
    setCartItems([]);
    setActiveScreen('order-confirmation');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const totalCartCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);

  return (
    <div className="min-h-screen flex flex-col bg-stone-50 text-stone-900 selection:bg-amber-100 selection:text-stone-900">
      
      {/* Navigation Header */}
      <Navbar
        activeScreen={activeScreen}
        setActiveScreen={setActiveScreen}
        selectedCategory={selectedCategory}
        setSelectedCategory={setSelectedCategory}
        cartCount={totalCartCount}
        wishlistCount={wishlistIds.length}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        onOpenCartDrawer={() => setIsCartDrawerOpen(true)}
        onOpenAndroidModal={() => setIsAndroidModalOpen(true)}
      />

      {/* Main Content View Switcher */}
      <main className="flex-1">
        {activeScreen === 'home' && (
          <HomePage
            products={SAMPLE_PRODUCTS}
            onSelectProduct={handleSelectProduct}
            onQuickAddToCart={(prod) => handleAddToCart(prod, {}, 1)}
            wishlist={wishlistIds}
            onToggleWishlist={handleToggleWishlist}
            onSelectCategory={(cat) => {
              setSelectedCategory(cat);
              setActiveScreen('shop');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onNavigateToShop={() => {
              setSelectedCategory('all');
              setActiveScreen('shop');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}

        {activeScreen === 'shop' && (
          <ShopPage
            products={SAMPLE_PRODUCTS}
            selectedCategory={selectedCategory}
            setSelectedCategory={setSelectedCategory}
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
            onSelectProduct={handleSelectProduct}
            onQuickAddToCart={(prod) => handleAddToCart(prod, {}, 1)}
            wishlist={wishlistIds}
            onToggleWishlist={handleToggleWishlist}
          />
        )}

        {activeScreen === 'product-detail' && selectedProduct && (
          <ProductDetailPage
            product={selectedProduct}
            allProducts={SAMPLE_PRODUCTS}
            onBack={() => {
              setActiveScreen('shop');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onAddToCart={handleAddToCart}
            isWishlisted={wishlistIds.includes(selectedProduct.id)}
            onToggleWishlist={handleToggleWishlist}
            onSelectProduct={handleSelectProduct}
          />
        )}

        {activeScreen === 'cart' && (
          <CartPage
            items={cartItems}
            onUpdateQuantity={handleUpdateQuantity}
            onRemoveItem={handleRemoveFromCart}
            onClearCart={handleClearCart}
            onContinueShopping={() => {
              setActiveScreen('shop');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onProceedToCheckout={() => {
              setActiveScreen('checkout');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}

        {activeScreen === 'checkout' && (
          <CheckoutPage
            items={cartItems}
            onBackToCart={() => {
              setActiveScreen('cart');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onOrderSubmitted={handleOrderSubmitted}
          />
        )}

        {activeScreen === 'order-confirmation' && (
          <OrderConfirmationPage
            order={currentOrder || {
              provisionalId: 'ZM-DEMO',
              items: [],
              subtotal: 0,
              shippingFee: 0,
              total: 0,
              customer: {
                fullName: 'Valued Customer',
                phone: '0300-1234567',
                city: 'Lahore',
                address: 'Main Boulevard, Gulberg, Lahore',
                paymentMethod: 'cash_on_delivery'
              },
              createdAt: new Date().toISOString(),
              whatsappMessage: 'Order details',
              status: 'awaiting_confirmation'
            }}
            onContinueShopping={() => {
              setActiveScreen('home');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}

        {activeScreen === 'wishlist' && (
          <WishlistPage
            wishlistIds={wishlistIds}
            allProducts={SAMPLE_PRODUCTS}
            onRemoveFromWishlist={handleToggleWishlist}
            onClearWishlist={() => setWishlistIds([])}
            onAddToCart={(prod) => handleAddToCart(prod, {}, 1)}
            onSelectProduct={handleSelectProduct}
            onContinueShopping={() => {
              setActiveScreen('shop');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}

        {activeScreen === 'about' && <AboutPage />}

        {activeScreen === 'contact' && <ContactPage />}

        {activeScreen === 'policies' && (
          <PoliciesPage
            activeTab={selectedPolicyTab}
            onSelectTab={setSelectedPolicyTab}
          />
        )}
      </main>

      {/* Cart Drawer Overlay */}
      <CartDrawer
        isOpen={isCartDrawerOpen}
        onClose={() => setIsCartDrawerOpen(false)}
        items={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveFromCart}
        onGoToCheckout={() => {
          setIsCartDrawerOpen(false);
          setActiveScreen('checkout');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onGoToCartPage={() => {
          setIsCartDrawerOpen(false);
          setActiveScreen('cart');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
      />

      {/* Android Packaging & Play Store Guide Modal */}
      <AndroidModal
        isOpen={isAndroidModalOpen}
        onClose={() => setIsAndroidModalOpen(false)}
      />

      {/* Footer */}
      <Footer
        setActiveScreen={setActiveScreen}
        setSelectedCategory={setSelectedCategory}
        setSelectedPolicyTab={setSelectedPolicyTab}
        onOpenAndroidModal={() => setIsAndroidModalOpen(true)}
      />

      {/* Mobile Bottom Navigation Bar */}
      <BottomNav
        activeScreen={activeScreen}
        setActiveScreen={setActiveScreen}
        cartCount={totalCartCount}
        wishlistCount={wishlistIds.length}
        onOpenCartDrawer={() => setIsCartDrawerOpen(true)}
      />

      {/* Subtle Toast Feedback */}
      {toastMessage && (
        <div className="fixed bottom-16 sm:bottom-6 right-4 sm:right-6 z-50 bg-stone-900 text-stone-100 text-xs sm:text-sm font-medium px-4 py-2.5 rounded-xl shadow-2xl flex items-center gap-2 border border-stone-800 animate-fade-in">
          <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
          <span>{toastMessage}</span>
        </div>
      )}

    </div>
  );
}
