import React from 'react';
import { 
  FileText, 
  Truck, 
  RotateCcw, 
  ShieldCheck, 
  HelpCircle, 
  AlertTriangle,
  ChevronDown
} from 'lucide-react';
import { PolicyTab } from '../types';
import { ZAVELLO_WHATSAPP_DISPLAY, ZAVELLO_EMAIL } from '../services/whatsapp';

interface PoliciesPageProps {
  activeTab: PolicyTab;
  onSelectTab: (tab: PolicyTab) => void;
}

export const PoliciesPage: React.FC<PoliciesPageProps> = ({
  activeTab,
  onSelectTab
}) => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-8">
      
      {/* Title */}
      <div>
        <span className="text-xs font-bold uppercase tracking-wider text-amber-700">Documentation</span>
        <h1 className="font-serif-brand text-2xl sm:text-3xl lg:text-4xl font-bold text-stone-900 mt-0.5">
          Policies & Customer Help Desk
        </h1>
        <p className="text-xs text-stone-500 mt-1">
          Review our delivery parameters, returns process, draft terms, and frequently asked questions for Pakistan.
        </p>
      </div>

      {/* Draft Disclaimer Notice */}
      <div className="p-4 bg-amber-50/80 border border-amber-200 rounded-xl flex items-start gap-3 text-xs text-amber-950">
        <AlertTriangle size={18} className="text-amber-700 shrink-0 mt-0.5" />
        <div>
          <strong className="text-amber-900 font-bold block mb-0.5">
            Operational Draft Notice:
          </strong>
          <p className="leading-relaxed">
            These policy documents are structured working drafts designed for Zavello Market's online retail operations in Pakistan. They reflect standard courier and supplier-fulfillment standards and remain subject to periodic review by Zavello Market management.
          </p>
        </div>
      </div>

      {/* Tabs Selector */}
      <div className="flex border-b border-stone-200 overflow-x-auto gap-2 sm:gap-6 pb-1">
        <button
          onClick={() => onSelectTab('shipping')}
          className={`flex items-center gap-2 pb-3 px-1 text-xs sm:text-sm font-bold whitespace-nowrap transition border-b-2 ${
            activeTab === 'shipping'
              ? 'border-stone-900 text-stone-900'
              : 'border-transparent text-stone-400 hover:text-stone-700'
          }`}
        >
          <Truck size={16} />
          <span>Shipping & Delivery</span>
        </button>

        <button
          onClick={() => onSelectTab('returns')}
          className={`flex items-center gap-2 pb-3 px-1 text-xs sm:text-sm font-bold whitespace-nowrap transition border-b-2 ${
            activeTab === 'returns'
              ? 'border-stone-900 text-stone-900'
              : 'border-transparent text-stone-400 hover:text-stone-700'
          }`}
        >
          <RotateCcw size={16} />
          <span>Returns & Refunds</span>
        </button>

        <button
          onClick={() => onSelectTab('faq')}
          className={`flex items-center gap-2 pb-3 px-1 text-xs sm:text-sm font-bold whitespace-nowrap transition border-b-2 ${
            activeTab === 'faq'
              ? 'border-stone-900 text-stone-900'
              : 'border-transparent text-stone-400 hover:text-stone-700'
          }`}
        >
          <HelpCircle size={16} />
          <span>Frequently Asked Questions</span>
        </button>

        <button
          onClick={() => onSelectTab('privacy')}
          className={`flex items-center gap-2 pb-3 px-1 text-xs sm:text-sm font-bold whitespace-nowrap transition border-b-2 ${
            activeTab === 'privacy'
              ? 'border-stone-900 text-stone-900'
              : 'border-transparent text-stone-400 hover:text-stone-700'
          }`}
        >
          <ShieldCheck size={16} />
          <span>Privacy Policy</span>
        </button>

        <button
          onClick={() => onSelectTab('terms')}
          className={`flex items-center gap-2 pb-3 px-1 text-xs sm:text-sm font-bold whitespace-nowrap transition border-b-2 ${
            activeTab === 'terms'
              ? 'border-stone-900 text-stone-900'
              : 'border-transparent text-stone-400 hover:text-stone-700'
          }`}
        >
          <FileText size={16} />
          <span>Terms & Conditions</span>
        </button>
      </div>

      {/* Content for Selected Tab */}
      <div className="bg-white rounded-2xl border border-stone-200 p-6 sm:p-8 text-xs sm:text-sm text-stone-700 leading-relaxed space-y-6">
        
        {/* TAB: SHIPPING */}
        {activeTab === 'shipping' && (
          <div className="space-y-4">
            <h2 className="font-serif-brand text-xl font-bold text-stone-900">
              Shipping & Delivery in Pakistan
            </h2>
            <p>
              Zavello Market delivers to residential and commercial addresses in all provinces of Pakistan (Punjab, Sindh, Khyber Pakhtunkhwa, Balochistan, Islamabad Capital Territory, and Azad Kashmir).
            </p>

            <h3 className="font-bold text-stone-900 pt-2">1. Delivery Timelines</h3>
            <ul className="list-disc pl-5 space-y-1.5 text-stone-600">
              <li><strong>Tier 1 Metropolitan Centers (Karachi, Lahore, Islamabad, Rawalpindi):</strong> 2 to 3 business days from order confirmation.</li>
              <li><strong>Tier 2 Cities (Faisalabad, Multan, Sialkot, Gujranwala, Peshawar, Hyderabad):</strong> 3 to 4 business days.</li>
              <li><strong>Other Regional Districts & Remote Areas:</strong> 4 to 6 business days.</li>
            </ul>

            <h3 className="font-bold text-stone-900 pt-2">2. Delivery Charges</h3>
            <p>
              • <strong>Free Nationwide Delivery</strong> is offered on all orders with a subtotal of <strong>Rs. 3,000 or higher</strong>.<br />
              • A flat delivery charge of <strong>Rs. 250</strong> applies to orders below Rs. 3,000.
            </p>

            <h3 className="font-bold text-stone-900 pt-2">3. Cash on Delivery (COD) Procedure</h3>
            <p>
              When the courier partner (TCS, Leopard, Trax, or PostEx) arrives at your designated address, please have the exact change in Pakistani Rupees ready. The rider will hand over your parcel upon collecting the payment amount specified on the parcel invoice.
            </p>
          </div>
        )}

        {/* TAB: RETURNS */}
        {activeTab === 'returns' && (
          <div className="space-y-4">
            <h2 className="font-serif-brand text-xl font-bold text-stone-900">
              Returns, Exchanges & Refund Policy (Draft)
            </h2>
            <p>
              We want you to be completely satisfied with every order from Zavello Market. Please review our current return guidelines:
            </p>

            <h3 className="font-bold text-stone-900 pt-2">1. Eligibility for Return or Exchange</h3>
            <ul className="list-disc pl-5 space-y-1 text-stone-600">
              <li>Product delivered was incorrect (wrong item, wrong size, or wrong color sent).</li>
              <li>Product arrived physically damaged or with a verified manufacturing defect.</li>
              <li>Notification must be submitted to our WhatsApp support ({ZAVELLO_WHATSAPP_DISPLAY}) within <strong>7 calendar days</strong> of receiving delivery.</li>
            </ul>

            <h3 className="font-bold text-stone-900 pt-2">2. Non-Returnable Categories</h3>
            <p>
              Due to hygiene and safety regulations in Pakistan, <strong>unsealed cosmetics, opened body lotions/scrubs, and intimate apparel</strong> cannot be returned once opened, unless demonstrably defective upon arrival.
            </p>

            <h3 className="font-bold text-stone-900 pt-2">3. Refund Processing</h3>
            <p>
              Approved refunds for Cash on Delivery returns are disbursed via direct Pakistan Bank Transfer (IBAN), Raast ID, EasyPaisa, or JazzCash within 3 to 5 business days following return parcel inspection.
            </p>
          </div>
        )}

        {/* TAB: FAQ */}
        {activeTab === 'faq' && (
          <div className="space-y-4">
            <h2 className="font-serif-brand text-xl font-bold text-stone-900">
              Frequently Asked Questions (FAQ)
            </h2>

            <div className="space-y-3">
              <div className="p-4 bg-stone-50 rounded-xl border border-stone-200 space-y-1">
                <h4 className="font-bold text-stone-900 text-xs sm:text-sm">
                  Q: How do I place an order on Zavello Market?
                </h4>
                <p className="text-stone-600 text-xs">
                  Browse products, add your desired items to the shopping bag, proceed to Checkout, and tap <strong>"Submit Order via WhatsApp"</strong>. This opens a pre-filled chat with our support team where you can confirm your order in one click.
                </p>
              </div>

              <div className="p-4 bg-stone-50 rounded-xl border border-stone-200 space-y-1">
                <h4 className="font-bold text-stone-900 text-xs sm:text-sm">
                  Q: Is Cash on Delivery available in my city?
                </h4>
                <p className="text-stone-600 text-xs">
                  Yes! We support Cash on Delivery across almost all registered courier postal codes in Pakistan. You pay cash to the rider at your door.
                </p>
              </div>

              <div className="p-4 bg-stone-50 rounded-xl border border-stone-200 space-y-1">
                <h4 className="font-bold text-stone-900 text-xs sm:text-sm">
                  Q: How does supplier fulfillment work?
                </h4>
                <p className="text-stone-600 text-xs">
                  Zavello Market coordinates directly with verified manufacturing workshops and distributors. When you submit your order, our team verifies batch freshness and current inventory before dispatching your package.
                </p>
              </div>

              <div className="p-4 bg-stone-50 rounded-xl border border-stone-200 space-y-1">
                <h4 className="font-bold text-stone-900 text-xs sm:text-sm">
                  Q: Can I cancel or modify an order after submitting?
                </h4>
                <p className="text-stone-600 text-xs">
                  Yes, simply reply in your WhatsApp chat with our team before your package is dispatched to the courier hub.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* TAB: PRIVACY */}
        {activeTab === 'privacy' && (
          <div className="space-y-4">
            <h2 className="font-serif-brand text-xl font-bold text-stone-900">
              Customer Privacy Policy (Draft)
            </h2>
            <p>
              Zavello Market respects the privacy of our customers across Pakistan. This policy outlines how information is gathered and safeguarded.
            </p>

            <h3 className="font-bold text-stone-900 pt-2">1. Information We Collect</h3>
            <p>
              We only gather delivery information necessary to fulfill your order: your name, contact mobile number, city, and shipping address. We do <strong>not</strong> collect credit card numbers, debit PINs, or confidential banking credentials.
            </p>

            <h3 className="font-bold text-stone-900 pt-2">2. Use of Information</h3>
            <p>
              Customer details are shared strictly with our contracted courier partners (e.g. TCS, Leopard, Trax) to allow riders to navigate to your address and contact you before doorstep arrival. We do not sell customer databases to third-party marketers.
            </p>
          </div>
        )}

        {/* TAB: TERMS */}
        {activeTab === 'terms' && (
          <div className="space-y-4">
            <h2 className="font-serif-brand text-xl font-bold text-stone-900">
              Terms & Conditions of Service (Draft)
            </h2>
            <p>
              By accessing and using Zavello Market (zavellomarket.store), you acknowledge and agree to the following operational parameters:
            </p>

            <h3 className="font-bold text-stone-900 pt-2">1. Product Pricing & Descriptions</h3>
            <p>
              All prices are listed in Pakistani Rupee (PKR). Product images and descriptions represent sample catalog demonstration inventory. Specifications and stock are subject to verification upon WhatsApp consultation.
            </p>

            <h3 className="font-bold text-stone-900 pt-2">2. Order Formation</h3>
            <p>
              A submitted WhatsApp message constitutes a request to purchase. An order is finalized only when confirmed by a Zavello Market customer service representative with an agreed dispatch timeline.
            </p>
          </div>
        )}

      </div>

    </div>
  );
};
