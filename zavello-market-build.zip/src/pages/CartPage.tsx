import React from 'react';
import { 
  ShoppingBag, 
  Trash2, 
  Plus, 
  Minus, 
  ArrowRight, 
  ArrowLeft, 
  Truck, 
  ShieldCheck, 
  MessageCircle 
} from 'lucide-react';
import { CartItem } from '../types';
import { formatPKR, calculateShipping } from '../utils/currency';
import { getWhatsAppUrl } from '../services/whatsapp';

interface CartPageProps {
  items: CartItem[];
  onUpdateQuantity: (cartItemId: string, newQty: number) => void;
  onRemoveItem: (cartItemId: string) => void;
  onClearCart: () => void;
  onContinueShopping: () => void;
  onProceedToCheckout: () => void;
}

export const CartPage: React.FC<CartPageProps> = ({
  items,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  onContinueShopping,
  onProceedToCheckout
}) => {
  const subtotal = items.reduce((sum, item) => sum + item.unitPrice * item.quantity, 0);
  const shippingFee = calculateShipping(subtotal);
  const total = subtotal + shippingFee;
  const freeShippingThreshold = 3000;
  const freeShippingProgress = Math.min(100, Math.round((subtotal / freeShippingThreshold) * 100));
  const amountNeededForFreeShipping = Math.max(0, freeShippingThreshold - subtotal);

  if (items.length === 0) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-16 text-center">
        <div className="w-20 h-20 bg-stone-100 rounded-full flex items-center justify-center mx-auto mb-4 text-stone-400">
          <ShoppingBag size={36} className="stroke-1" />
        </div>
        <h2 className="font-serif-brand text-2xl font-bold text-stone-900">
          Your Shopping Bag is Empty
        </h2>
        <p className="text-xs sm:text-sm text-stone-500 mt-2 max-w-sm mx-auto">
          Explore Zavello Market's collection of curated fashion, beauty, skincare, and lifestyle essentials.
        </p>
        <button
          onClick={onContinueShopping}
          className="mt-6 px-6 py-3 bg-stone-900 hover:bg-stone-800 text-white font-semibold text-xs rounded-xl transition inline-flex items-center gap-2"
        >
          <ArrowLeft size={16} />
          <span>Start Shopping</span>
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 space-y-8">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-stone-200">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-amber-700">Review Items</span>
          <h1 className="font-serif-brand text-2xl sm:text-3xl font-bold text-stone-900 mt-0.5">
            Shopping Bag ({items.reduce((acc, i) => acc + i.quantity, 0)} Items)
          </h1>
        </div>

        <button
          onClick={onContinueShopping}
          className="text-xs font-semibold text-stone-600 hover:text-stone-900 flex items-center gap-1.5 self-start sm:self-auto"
        >
          <ArrowLeft size={14} />
          <span>Continue Shopping</span>
        </button>
      </div>

      {/* Free Shipping Gauge */}
      <div className="bg-amber-50/70 border border-amber-200/80 rounded-xl p-4 text-xs text-amber-900">
        <div className="flex items-center justify-between gap-2 mb-2">
          <div className="flex items-center gap-2 font-medium">
            <Truck size={16} className="text-amber-700 shrink-0" />
            {amountNeededForFreeShipping > 0 ? (
              <span>
                Add <strong>{formatPKR(amountNeededForFreeShipping)}</strong> more to get <strong>Free Nationwide Delivery</strong>!
              </span>
            ) : (
              <span className="text-emerald-800 font-bold">
                🎉 Congratulations! Your order qualifies for Free Nationwide Delivery across Pakistan.
              </span>
            )}
          </div>
          <span className="font-bold text-stone-700 hidden sm:inline">{freeShippingProgress}%</span>
        </div>
        <div className="w-full bg-amber-200/60 rounded-full h-2 overflow-hidden">
          <div 
            className="bg-amber-600 h-2 rounded-full transition-all duration-300"
            style={{ width: `${freeShippingProgress}%` }}
          />
        </div>
      </div>

      {/* Main Grid: Cart Items + Order Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Cart Items List */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-white rounded-xl border border-stone-200 divide-y divide-stone-100">
            {items.map((item) => (
              <div key={item.id} className="p-4 sm:p-5 flex flex-col sm:flex-row gap-4 items-start sm:items-center">
                
                {/* Thumbnail */}
                <img
                  src={item.product.images[0]}
                  alt={item.product.name}
                  className="w-20 h-24 sm:w-24 sm:h-28 object-cover rounded-xl bg-stone-100 shrink-0"
                />

                {/* Info */}
                <div className="flex-1 min-w-0 space-y-1">
                  <div className="flex items-start justify-between gap-2">
                    <h3 className="text-sm sm:text-base font-bold text-stone-900">
                      {item.product.name}
                    </h3>
                    <button
                      onClick={() => onRemoveItem(item.id)}
                      className="text-stone-400 hover:text-rose-600 p-1 transition"
                      title="Remove item"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>

                  <p className="text-xs text-stone-500">
                    Category: {item.product.categoryLabel}
                  </p>

                  {/* Selected Variants */}
                  {Object.keys(item.selectedVariants).length > 0 && (
                    <div className="flex flex-wrap gap-1.5 pt-1">
                      {Object.entries(item.selectedVariants).map(([key, value]) => (
                        <span 
                          key={key}
                          className="text-[11px] bg-stone-100 text-stone-700 px-2 py-0.5 rounded font-medium"
                        >
                          {key}: <strong>{value}</strong>
                        </span>
                      ))}
                    </div>
                  )}

                  <div className="text-xs font-semibold text-stone-700 pt-1">
                    Unit Price: {formatPKR(item.unitPrice)}
                  </div>
                </div>

                {/* Quantity Controls & Line Total */}
                <div className="flex sm:flex-col items-center sm:items-end justify-between w-full sm:w-auto gap-3 pt-2 sm:pt-0">
                  <div className="flex items-center border border-stone-200 rounded-lg bg-stone-50">
                    <button
                      onClick={() => onUpdateQuantity(item.id, item.quantity - 1)}
                      className="p-1.5 text-stone-600 hover:bg-stone-200/70 transition rounded-l-lg"
                      aria-label="Decrease quantity"
                    >
                      <Minus size={14} />
                    </button>
                    <span className="px-3 text-xs font-bold text-stone-900 min-w-7 text-center">
                      {item.quantity}
                    </span>
                    <button
                      onClick={() => onUpdateQuantity(item.id, item.quantity + 1)}
                      className="p-1.5 text-stone-600 hover:bg-stone-200/70 transition rounded-r-lg"
                      aria-label="Increase quantity"
                    >
                      <Plus size={14} />
                    </button>
                  </div>

                  <div className="text-sm sm:text-base font-extrabold text-stone-900">
                    {formatPKR(item.unitPrice * item.quantity)}
                  </div>
                </div>

              </div>
            ))}
          </div>

          <div className="flex justify-between items-center px-1">
            <button
              onClick={onClearCart}
              className="text-xs text-stone-400 hover:text-rose-600 transition"
            >
              Clear entire bag
            </button>
            <span className="text-xs text-stone-500">
              Prices include all applicable import/packing fees.
            </span>
          </div>
        </div>

        {/* Order Summary Sidebar */}
        <div className="space-y-4">
          <div className="bg-white rounded-xl border border-stone-200 p-5 sm:p-6 space-y-4 shadow-xs">
            <h3 className="font-bold text-stone-900 text-base border-b border-stone-100 pb-3">
              Order Summary
            </h3>

            <div className="space-y-2 text-xs">
              <div className="flex justify-between text-stone-600">
                <span>Subtotal</span>
                <span className="font-bold text-stone-900">{formatPKR(subtotal)}</span>
              </div>

              <div className="flex justify-between text-stone-600">
                <span>Delivery Fee</span>
                <span className="font-bold text-stone-900">
                  {shippingFee === 0 ? (
                    <span className="text-emerald-700 font-extrabold">FREE</span>
                  ) : (
                    formatPKR(shippingFee)
                  )}
                </span>
              </div>

              <div className="text-[11px] text-stone-500 bg-stone-50 p-2.5 rounded-lg border border-stone-100">
                *Delivery fees & final dispatch confirmed upon WhatsApp verification.
              </div>

              <div className="border-t border-stone-200 pt-3 flex justify-between text-base font-extrabold text-stone-900">
                <span>Estimated Total</span>
                <span>{formatPKR(total)}</span>
              </div>
            </div>

            <button
              onClick={onProceedToCheckout}
              className="w-full py-3.5 bg-stone-900 hover:bg-stone-800 text-white rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition shadow-md"
            >
              <span>Proceed to Checkout</span>
              <ArrowRight size={16} />
            </button>

            <div className="pt-2 border-t border-stone-100 space-y-2 text-[11px] text-stone-600">
              <div className="flex items-center gap-2">
                <ShieldCheck size={14} className="text-emerald-600 shrink-0" />
                <span>Cash on Delivery (Pay upon receiving parcel)</span>
              </div>
              <div className="flex items-center gap-2">
                <Truck size={14} className="text-stone-700 shrink-0" />
                <span>2-4 Business days across Pakistan</span>
              </div>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
};
