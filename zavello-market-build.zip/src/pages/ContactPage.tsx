import React, { useState } from 'react';
import { 
  Phone, 
  Mail, 
  Globe, 
  MessageCircle, 
  Clock, 
  Send, 
  ExternalLink,
  ShieldCheck 
} from 'lucide-react';
import { 
  ZAVELLO_EMAIL, 
  ZAVELLO_STORE_URL, 
  ZAVELLO_WHATSAPP_DISPLAY, 
  getWhatsAppUrl 
} from '../services/whatsapp';

export const ContactPage: React.FC = () => {
  const [name, setName] = useState('');
  const [topic, setTopic] = useState('Order Tracking / Inquiry');
  const [message, setMessage] = useState('');

  const handleSendWhatsAppQuery = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !message.trim()) return;

    const queryText = `*📩 CUSTOMER INQUIRY — ZAVELLO MARKET*
From: ${name.trim()}
Topic: ${topic}

Message:
"${message.trim()}"

Please assist me on WhatsApp. Thank you!`;

    window.open(getWhatsAppUrl(queryText), '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-10">
      
      {/* Title */}
      <div className="text-center space-y-2">
        <span className="text-xs font-bold uppercase tracking-wider text-amber-700">Support & Inquiries</span>
        <h1 className="font-serif-brand text-3xl sm:text-4xl font-bold text-stone-900">
          Get in Touch with Zavello Market
        </h1>
        <p className="text-xs sm:text-sm text-stone-600 max-w-md mx-auto">
          We are here to assist with product inquiries, order tracking across Pakistan, and sizing recommendations.
        </p>
      </div>

      {/* Contact Channels Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        
        {/* WhatsApp */}
        <a
          href={getWhatsAppUrl("Hello Zavello Market! I need assistance with an order.")}
          target="_blank"
          rel="noopener noreferrer"
          className="p-5 bg-emerald-50 rounded-2xl border border-emerald-200/80 hover:border-emerald-300 transition flex flex-col justify-between group"
        >
          <div>
            <div className="p-3 bg-emerald-600 text-white rounded-xl w-fit mb-3">
              <Phone size={20} />
            </div>
            <h3 className="font-bold text-stone-900 text-sm">WhatsApp Assistance</h3>
            <p className="text-xs text-stone-600 mt-1">
              Direct chat with our representative in Pakistan.
            </p>
          </div>
          <div className="mt-4 pt-3 border-t border-emerald-200/60 font-semibold text-xs text-emerald-800 flex items-center justify-between">
            <span>{ZAVELLO_WHATSAPP_DISPLAY}</span>
            <ExternalLink size={13} className="group-hover:translate-x-0.5 transition-transform" />
          </div>
        </a>

        {/* Email */}
        <a
          href={`mailto:${ZAVELLO_EMAIL}`}
          className="p-5 bg-stone-50 rounded-2xl border border-stone-200 hover:border-stone-300 transition flex flex-col justify-between group"
        >
          <div>
            <div className="p-3 bg-stone-900 text-white rounded-xl w-fit mb-3">
              <Mail size={20} />
            </div>
            <h3 className="font-bold text-stone-900 text-sm">Business Email</h3>
            <p className="text-xs text-stone-600 mt-1">
              For business partnerships, supplier quotes & feedback.
            </p>
          </div>
          <div className="mt-4 pt-3 border-t border-stone-200 font-semibold text-xs text-stone-900 flex items-center justify-between truncate">
            <span className="truncate">{ZAVELLO_EMAIL}</span>
            <ExternalLink size={13} className="shrink-0 group-hover:translate-x-0.5 transition-transform" />
          </div>
        </a>

        {/* Official Website */}
        <a
          href={ZAVELLO_STORE_URL}
          target="_blank"
          rel="noopener noreferrer"
          className="p-5 bg-stone-50 rounded-2xl border border-stone-200 hover:border-stone-300 transition flex flex-col justify-between group"
        >
          <div>
            <div className="p-3 bg-stone-800 text-white rounded-xl w-fit mb-3">
              <Globe size={20} />
            </div>
            <h3 className="font-bold text-stone-900 text-sm">Store Web Domain</h3>
            <p className="text-xs text-stone-600 mt-1">
              Official retail web portal for Zavello Market.
            </p>
          </div>
          <div className="mt-4 pt-3 border-t border-stone-200 font-semibold text-xs text-stone-900 flex items-center justify-between">
            <span>zavellomarket.store</span>
            <ExternalLink size={13} className="group-hover:translate-x-0.5 transition-transform" />
          </div>
        </a>

      </div>

      {/* Inquiry Form */}
      <div className="bg-white rounded-2xl border border-stone-200 p-6 sm:p-8 space-y-6">
        <div className="flex items-center gap-2">
          <MessageCircle size={20} className="text-emerald-700" />
          <h2 className="font-serif-brand text-xl font-bold text-stone-900">
            Send an Instant Message to Zavello Support
          </h2>
        </div>
        <p className="text-xs text-stone-500">
          Fill out this quick form and click "Open in WhatsApp" to deliver your question straight to our active team.
        </p>

        <form onSubmit={handleSendWhatsAppQuery} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-stone-900 mb-1">
                Your Name <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                placeholder="Muhammad Ali / Fatima"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3.5 py-2.5 text-xs bg-stone-50 border border-stone-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-stone-400"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-900 mb-1">
                Topic
              </label>
              <select
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                className="w-full px-3.5 py-2.5 text-xs bg-stone-50 border border-stone-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-stone-400 cursor-pointer"
              >
                <option value="Order Tracking / Delivery">Order Tracking / Delivery</option>
                <option value="Product Availability / Restock">Product Availability / Restock</option>
                <option value="Size & Fabric Guidance">Size & Fabric Guidance</option>
                <option value="Return or Exchange Inquiry">Return or Exchange Inquiry</option>
                <option value="Bulk Order or Wholesale">Bulk Order or Wholesale</option>
                <option value="Other Question">Other Question</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-stone-900 mb-1">
              Your Message <span className="text-rose-500">*</span>
            </label>
            <textarea
              required
              rows={4}
              placeholder="How can we help you today?"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="w-full px-3.5 py-2.5 text-xs bg-stone-50 border border-stone-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-stone-400"
            />
          </div>

          <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-4">
            <button
              type="submit"
              className="w-full sm:w-auto px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition shadow-md"
            >
              <Send size={15} />
              <span>Send via WhatsApp (+92 325 9380039)</span>
            </button>
            <span className="text-[11px] text-stone-500">
              Operating hours: 10:00 AM – 9:00 PM PKT (Mon–Sat)
            </span>
          </div>
        </form>
      </div>

    </div>
  );
};
