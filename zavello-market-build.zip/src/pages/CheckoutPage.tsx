import React, { useState } from 'react';
import { 
  ArrowLeft, 
  MessageCircle, 
  ShieldCheck, 
  Truck, 
  AlertCircle, 
  Lock, 
  Check, 
  FileText 
} from 'lucide-react';
import { CartItem, CustomerInfo, OrderSubmission } from '../types';
import { formatPKR, calculateShipping } from '../utils/currency';
import { PAKISTAN_CITIES } from '../data/pakistanCities';
import { 
  buildWhatsAppOrderMessage, 
  getWhatsAppUrl, 
  ZAVELLO_WHATSAPP_DISPLAY 
} from '../services/whatsapp';
import { storageService } from '../services/storage';

interface CheckoutPageProps {
  items: CartItem[];
  onBackToCart: () => void;
  onOrderSubmitted: (order: OrderSubmission) => void;
}

export const CheckoutPage: React.FC<CheckoutPageProps> = ({
  items,
  onBackToCart,
  onOrderSubmitted
}) => {
  const savedCustomer = storageService.getSavedCustomer();

  const [fullName, setFullName] = useState(savedCustomer?.fullName || '');
  const [phone, setPhone] = useState(savedCustomer?.phone || '');
  const [city, setCity] = useState(savedCustomer?.city || 'Lahore');
  const [customCity, setCustomCity] = useState('');
  const [address, setAddress] = useState(savedCustomer?.address || '');
  const [notes, setNotes] = useState(savedCustomer?.notes || '');
  const [paymentMethod, setPaymentMethod] = useState<'cash_on_delivery' | 'bank_transfer_enquiry'>('cash_on_delivery');
  
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const subtotal = items.reduce((sum, item) => sum + item.unitPrice * item.quantity, 0);
  const shippingFee = calculateShipping(subtotal);
  const total = subtotal + shippingFee;

  // Validation
  const validateForm = (): boolean => {
    const errs: Record<string, string> = {};

    if (!fullName.trim() || fullName.trim().length < 3) {
      errs.fullName = 'Please enter your complete name (at least 3 characters)';
    }

    // Pakistani phone number check: 03XX XXXXXXX or +923XX XXXXXXX or 10-13 digits
    const cleanedPhone = phone.replace(/[\s-]/g, '');
    const isPakPhone = /^((\+92)|(0092)|(92)|(0))?3[0-9]{9}$/.test(cleanedPhone);
    if (!cleanedPhone) {
      errs.phone = 'Mobile number is required for WhatsApp confirmation';
    } else if (!isPakPhone && cleanedPhone.length < 10) {
      errs.phone = 'Please enter a valid Pakistani mobile number (e.g. 0300 1234567)';
    }

    const effectiveCity = city === 'Other (Enter Custom City)' ? customCity.trim() : city;
    if (!effectiveCity) {
      errs.city = 'Please specify your delivery city';
    }

    if (!address.trim() || address.trim().length < 8) {
      errs.address = 'Please provide complete delivery address with house/street number';
    }

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    setIsSubmitting(true);

    const effectiveCity = city === 'Other (Enter Custom City)' ? customCity.trim() : city;
    const provisionalId = `ZM-${Math.floor(100000 + Math.random() * 900000)}`;

    const customerData: CustomerInfo = {
      fullName: fullName.trim(),
      phone: phone.trim(),
      city: effectiveCity,
      address: address.trim(),
      notes: notes.trim(),
      paymentMethod
    };

    // Save for convenience
    storageService.saveCustomer(customerData);

    const whatsappMessage = buildWhatsAppOrderMessage(
      provisionalId,
      items,
      subtotal,
      shippingFee,
      total,
      customerData
    );

    const submission: OrderSubmission = {
      provisionalId,
      items,
      subtotal,
      shippingFee,
      total,
      customer: customerData,
      createdAt: new Date().toISOString(),
      whatsappMessage,
      status: 'awaiting_confirmation'
    };

    storageService.saveLastOrder(submission);

    // Open WhatsApp link safely
    const waUrl = getWhatsAppUrl(whatsappMessage);
    
    try {
      // In web environments, open in a new tab/window for WhatsApp web or mobile deep link
      window.open(waUrl, '_blank', 'noopener,noreferrer');
    } catch (err) {
      console.warn('Could not open WhatsApp directly', err);
    }

    // Transition to order confirmation screen
    onOrderSubmitted(submission);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 space-y-8">
      
      {/* Top Header */}
      <div className="flex items-center justify-between pb-4 border-b border-stone-200">
        <div>
          <button
            onClick={onBackToCart}
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-stone-600 hover:text-stone-900 transition mb-2"
          >
            <ArrowLeft size={14} />
            <span>Return to Bag</span>
          </button>
          <h1 className="font-serif-brand text-2xl sm:text-3xl font-bold text-stone-900">
            Checkout & WhatsApp Dispatch
          </h1>
          <p className="text-xs text-stone-500 mt-1">
            Deliver to your doorstep in Pakistan • Pay Cash on Delivery
          </p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left Form: Delivery & Customer Info */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Card: Customer Information */}
          <div className="bg-white rounded-xl border border-stone-200 p-5 sm:p-6 space-y-4">
            <h2 className="text-sm sm:text-base font-bold text-stone-900 flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-stone-900 text-white flex items-center justify-center text-xs">1</span>
              <span>Delivery Details (Pakistan)</span>
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              
              {/* Full Name */}
              <div className="sm:col-span-2">
                <label className="block text-xs font-bold text-stone-900 mb-1">
                  Full Name <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  placeholder="e.g. Muhammad Ali / Ayesha Khan"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className={`w-full px-3.5 py-2.5 text-xs bg-stone-50 border rounded-lg focus:outline-none focus:ring-1 ${
                    errors.fullName ? 'border-rose-400 focus:ring-rose-400' : 'border-stone-300 focus:ring-stone-400'
                  }`}
                />
                {errors.fullName && (
                  <p className="text-[11px] text-rose-500 mt-1 flex items-center gap-1">
                    <AlertCircle size={12} />
                    <span>{errors.fullName}</span>
                  </p>
                )}
              </div>

              {/* Mobile Phone */}
              <div>
                <label className="block text-xs font-bold text-stone-900 mb-1">
                  WhatsApp / Mobile Number <span className="text-rose-500">*</span>
                </label>
                <input
                  type="tel"
                  placeholder="0300 1234567"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className={`w-full px-3.5 py-2.5 text-xs bg-stone-50 border rounded-lg focus:outline-none focus:ring-1 ${
                    errors.phone ? 'border-rose-400 focus:ring-rose-400' : 'border-stone-300 focus:ring-stone-400'
                  }`}
                />
                <p className="text-[10px] text-stone-400 mt-1">
                  Used by courier rider and WhatsApp support
                </p>
                {errors.phone && (
                  <p className="text-[11px] text-rose-500 mt-1 flex items-center gap-1">
                    <AlertCircle size={12} />
                    <span>{errors.phone}</span>
                  </p>
                )}
              </div>

              {/* City */}
              <div>
                <label className="block text-xs font-bold text-stone-900 mb-1">
                  City <span className="text-rose-500">*</span>
                </label>
                <select
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-xs bg-stone-50 border border-stone-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-stone-400 cursor-pointer"
                >
                  {PAKISTAN_CITIES.map((c) => (
                    <option key={c.name} value={c.name}>
                      {c.name} ({c.province})
                    </option>
                  ))}
                </select>

                {city === 'Other (Enter Custom City)' && (
                  <input
                    type="text"
                    placeholder="Enter your town or city name"
                    value={customCity}
                    onChange={(e) => setCustomCity(e.target.value)}
                    className="w-full mt-2 px-3 py-2 text-xs bg-white border border-stone-300 rounded-lg"
                  />
                )}

                {errors.city && (
                  <p className="text-[11px] text-rose-500 mt-1 flex items-center gap-1">
                    <AlertCircle size={12} />
                    <span>{errors.city}</span>
                  </p>
                )}
              </div>

              {/* Complete Address */}
              <div className="sm:col-span-2">
                <label className="block text-xs font-bold text-stone-900 mb-1">
                  Complete Street / House Address <span className="text-rose-500">*</span>
                </label>
                <textarea
                  rows={3}
                  placeholder="House / Flat #, Street, Sector / Area / Colony, Landmark"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className={`w-full px-3.5 py-2.5 text-xs bg-stone-50 border rounded-lg focus:outline-none focus:ring-1 ${
                    errors.address ? 'border-rose-400 focus:ring-rose-400' : 'border-stone-300 focus:ring-stone-400'
                  }`}
                />
                {errors.address && (
                  <p className="text-[11px] text-rose-500 mt-1 flex items-center gap-1">
                    <AlertCircle size={12} />
                    <span>{errors.address}</span>
                  </p>
                )}
              </div>

              {/* Order Notes */}
              <div className="sm:col-span-2">
                <label className="block text-xs font-medium text-stone-700 mb-1">
                  Special Delivery Instructions (Optional)
                </label>
                <input
                  type="text"
                  placeholder="e.g. Call before delivery, deliver in afternoon, gift packaging..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full px-3.5 py-2 text-xs bg-stone-50 border border-stone-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-stone-400"
                />
              </div>

            </div>
          </div>

          {/* Card: Payment Selection */}
          <div className="bg-white rounded-xl border border-stone-200 p-5 sm:p-6 space-y-4">
            <h2 className="text-sm sm:text-base font-bold text-stone-900 flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-stone-900 text-white flex items-center justify-center text-xs">2</span>
              <span>Requested Payment Method</span>
            </h2>

            <div className="space-y-3">
              <label 
                className={`flex items-start gap-3 p-3.5 rounded-xl border cursor-pointer transition ${
                  paymentMethod === 'cash_on_delivery' 
                    ? 'border-stone-900 bg-stone-50/70 ring-1 ring-stone-900' 
                    : 'border-stone-200 hover:border-stone-300'
                }`}
              >
                <input
                  type="radio"
                  name="payment"
                  checked={paymentMethod === 'cash_on_delivery'}
                  onChange={() => setPaymentMethod('cash_on_delivery')}
                  className="mt-1 accent-stone-900"
                />
                <div className="space-y-0.5">
                  <div className="flex items-center gap-2">
                    <span className="text-xs sm:text-sm font-bold text-stone-900">Cash on Delivery (COD)</span>
                    <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.2 rounded">Recommended</span>
                  </div>
                  <p className="text-[11px] text-stone-600">
                    Pay in cash directly to the courier rider upon delivery of your parcel.
                  </p>
                  <p className="text-[10px] text-amber-800 italic pt-1">
                    *Availability is verified by our team on WhatsApp before courier booking.
                  </p>
                </div>
              </label>

              <label 
                className={`flex items-start gap-3 p-3.5 rounded-xl border cursor-pointer transition ${
                  paymentMethod === 'bank_transfer_enquiry' 
                    ? 'border-stone-900 bg-stone-50/70 ring-1 ring-stone-900' 
                    : 'border-stone-200 hover:border-stone-300'
                }`}
              >
                <input
                  type="radio"
                  name="payment"
                  checked={paymentMethod === 'bank_transfer_enquiry'}
                  onChange={() => setPaymentMethod('bank_transfer_enquiry')}
                  className="mt-1 accent-stone-900"
                />
                <div className="space-y-0.5">
                  <span className="text-xs sm:text-sm font-bold text-stone-900">
                    Online Bank Transfer / Raast / EasyPaisa / JazzCash Enquiry
                  </span>
                  <p className="text-[11px] text-stone-600">
                    Request our official Zavello Market business account IBAN or Raast ID on WhatsApp.
                  </p>
                </div>
              </label>
            </div>

            {/* Zero card request notice */}
            <div className="flex items-center gap-2 p-3 bg-stone-100 rounded-lg text-[11px] text-stone-600">
              <Lock size={14} className="text-stone-800 shrink-0" />
              <span>We never ask for credit card numbers or banking passwords on this app.</span>
            </div>
          </div>

          {/* Honest Disclosure Box */}
          <div className="p-4 bg-amber-50/80 border border-amber-200/90 rounded-xl space-y-2 text-xs text-amber-950">
            <h4 className="font-bold flex items-center gap-1.5 text-amber-900">
              <ShieldCheck size={16} className="text-amber-700" />
              <span>Order Protocol & Transparency:</span>
            </h4>
            <p className="leading-relaxed">
              Clicking <strong>"Submit Order via WhatsApp"</strong> will prepare your complete order text and open WhatsApp with Zavello Market (+92 325 9380039). 
              <strong> You must press "Send" in WhatsApp.</strong> Our representative will verify supplier availability and confirm dispatch with your tracking number.
            </p>
          </div>

        </div>

        {/* Right Sidebar: Order Recap & Submission Button */}
        <div className="space-y-4">
          <div className="bg-white rounded-xl border border-stone-200 p-5 space-y-4 shadow-xs sticky top-24">
            <h3 className="font-bold text-stone-900 text-sm border-b border-stone-100 pb-2.5">
              Items in Order ({items.length})
            </h3>

            {/* Mini Items list */}
            <div className="space-y-2.5 max-h-60 overflow-y-auto pr-1">
              {items.map((item) => (
                <div key={item.id} className="flex gap-2.5 text-xs pb-2 border-b border-stone-100 last:border-0">
                  <img
                    src={item.product.images[0]}
                    alt={item.product.name}
                    className="w-12 h-14 object-cover rounded bg-stone-100 shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <h4 className="font-semibold text-stone-900 truncate">
                      {item.product.name}
                    </h4>
                    <p className="text-[10px] text-stone-500">
                      Qty: {item.quantity} × {formatPKR(item.unitPrice)}
                    </p>
                    {Object.keys(item.selectedVariants).length > 0 && (
                      <p className="text-[10px] text-stone-600 truncate">
                        {Object.entries(item.selectedVariants).map(([k, v]) => `${k}: ${v}`).join(', ')}
                      </p>
                    )}
                  </div>
                  <span className="font-bold text-stone-900 shrink-0">
                    {formatPKR(item.unitPrice * item.quantity)}
                  </span>
                </div>
              ))}
            </div>

            {/* Price Calculations */}
            <div className="space-y-2 pt-2 border-t border-stone-200 text-xs">
              <div className="flex justify-between text-stone-600">
                <span>Subtotal</span>
                <span className="font-bold text-stone-900">{formatPKR(subtotal)}</span>
              </div>
              <div className="flex justify-between text-stone-600">
                <span>Nationwide Courier</span>
                <span className="font-bold text-stone-900">
                  {shippingFee === 0 ? (
                    <span className="text-emerald-700 font-extrabold uppercase">Free</span>
                  ) : (
                    formatPKR(shippingFee)
                  )}
                </span>
              </div>
              <div className="border-t border-stone-200 pt-2 flex justify-between text-base font-extrabold text-stone-900">
                <span>Estimated Total</span>
                <span>{formatPKR(total)}</span>
              </div>
            </div>

            {/* Primary Action Button */}
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition shadow-md disabled:opacity-60 cursor-pointer"
            >
              <MessageCircle size={18} />
              <span>Submit Order via WhatsApp</span>
            </button>

            <p className="text-[10px] text-stone-500 text-center leading-tight">
              Opens WhatsApp chat with Zavello Market (+92 325 9380039). No credit card required.
            </p>
          </div>
        </div>

      </form>

    </div>
  );
};
