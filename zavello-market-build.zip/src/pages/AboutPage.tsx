import React from 'react';
import { 
  ShoppingBag, 
  ShieldCheck, 
  Truck, 
  MessageCircle, 
  Globe, 
  Mail, 
  Phone,
  Sparkles,
  ExternalLink 
} from 'lucide-react';
import { 
  ZAVELLO_EMAIL, 
  ZAVELLO_STORE_URL, 
  ZAVELLO_WHATSAPP_DISPLAY, 
  getWhatsAppUrl 
} from '../services/whatsapp';

export const AboutPage: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-12">
      
      {/* Header */}
      <div className="text-center space-y-3">
        <span className="text-xs font-bold uppercase tracking-widest text-amber-700 bg-amber-50 px-3 py-1 rounded-full">
          About Zavello Market
        </span>
        <h1 className="font-serif-brand text-3xl sm:text-4xl lg:text-5xl font-bold text-stone-900">
          Curated Essentials for Everyday Pakistan
        </h1>
        <p className="text-xs sm:text-sm text-stone-600 max-w-xl mx-auto leading-relaxed">
          An online shopping destination dedicated to providing accessible fashion, skincare, cosmetics, accessories, and aesthetic lifestyle products across Pakistan.
        </p>
      </div>

      {/* Hero Brand Card */}
      <div className="bg-stone-900 text-stone-100 rounded-2xl p-6 sm:p-10 space-y-6">
        <div className="flex items-center gap-2">
          <span className="font-serif-brand text-2xl sm:text-3xl font-extrabold tracking-wider text-white">
            ZAVELLO
          </span>
          <span className="text-xs uppercase tracking-widest px-2 py-0.5 bg-amber-400 text-stone-900 font-bold rounded">
            MARKET
          </span>
        </div>

        <p className="text-xs sm:text-sm text-stone-300 leading-relaxed">
          Zavello Market operates with a straightforward mission: bringing tasteful, modern essentials directly to Pakistani households without inflated retail markups or complex checkout barriers. From everyday lawn and linen wear to skin-friendly serums and handcrafted home accents, we connect you with thoughtfully curated collections.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4 border-t border-stone-800 text-xs">
          <div>
            <strong className="text-white block mb-1">Primary Market</strong>
            <span className="text-stone-400">Pakistan (Nationwide Delivery)</span>
          </div>
          <div>
            <strong className="text-white block mb-1">Payment Method</strong>
            <span className="text-stone-400">Cash on Delivery (COD)</span>
          </div>
          <div>
            <strong className="text-white block mb-1">Customer Support</strong>
            <span className="text-stone-400">Direct WhatsApp Assistance</span>
          </div>
        </div>
      </div>

      {/* Honest Sourcing & Fulfillment Model */}
      <div className="bg-white rounded-2xl border border-stone-200 p-6 sm:p-8 space-y-4">
        <div className="flex items-center gap-2 text-amber-800 font-bold text-sm uppercase tracking-wide">
          <ShieldCheck size={18} className="text-amber-700" />
          <span>Our Fulfillment & Sourcing Philosophy</span>
        </div>

        <h2 className="font-serif-brand text-xl sm:text-2xl font-bold text-stone-900">
          Transparent Supplier-Backed Retail
        </h2>

        <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">
          We believe in honest commerce. Zavello Market collaborates directly with vetted textile producers, cosmetics distributors, and lifestyle manufacturers throughout Pakistan. Rather than storing millions in speculative warehouse inventory, we verify live batch availability and quality standards directly before confirming orders with you on WhatsApp.
        </p>

        <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">
          This model keeps prices fair for Pakistani consumers and guarantees that cosmetics and body care formulas are from fresh production batches.
        </p>
      </div>

      {/* Department Pillars */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-stone-50 p-6 rounded-xl border border-stone-200 space-y-2">
          <span className="text-2xl">👗</span>
          <h3 className="font-bold text-stone-900 text-sm">Fashion & Pret Wear</h3>
          <p className="text-xs text-stone-600 leading-relaxed">
            Comfortable linen co-ords, tailored cotton shirts, and embroidered festive kurtis suitable for our local climate.
          </p>
        </div>

        <div className="bg-stone-50 p-6 rounded-xl border border-stone-200 space-y-2">
          <span className="text-2xl">💄</span>
          <h3 className="font-bold text-stone-900 text-sm">Beauty & Body Care</h3>
          <p className="text-xs text-stone-600 leading-relaxed">
            High-pigment velvet lip mousse, hydrating glow primers, and botanical argan moisturizers tested for daily comfort.
          </p>
        </div>

        <div className="bg-stone-50 p-6 rounded-xl border border-stone-200 space-y-2">
          <span className="text-2xl">🕯️</span>
          <h3 className="font-bold text-stone-900 text-sm">Accessories & Living</h3>
          <p className="text-xs text-stone-600 leading-relaxed">
            Hand-poured amber soy candles, anti-tarnish jewelry, and mulberry silk sleep accessories designed to elevate your everyday space.
          </p>
        </div>
      </div>

      {/* Official Contact & Brand Channels */}
      <div className="bg-white rounded-2xl border border-stone-200 p-6 sm:p-8 space-y-4">
        <h3 className="font-bold text-stone-900 text-base">
          Official Channels & Verification
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
          <a
            href={getWhatsAppUrl("Hello Zavello Market!")}
            target="_blank"
            rel="noopener noreferrer"
            className="p-3.5 rounded-xl bg-emerald-50 text-emerald-950 border border-emerald-200 flex flex-col gap-1 hover:bg-emerald-100 transition"
          >
            <div className="flex items-center gap-1.5 font-bold">
              <Phone size={14} className="text-emerald-700" />
              <span>Official WhatsApp</span>
            </div>
            <span>{ZAVELLO_WHATSAPP_DISPLAY}</span>
          </a>

          <a
            href={`mailto:${ZAVELLO_EMAIL}`}
            className="p-3.5 rounded-xl bg-stone-50 text-stone-900 border border-stone-200 flex flex-col gap-1 hover:bg-stone-100 transition"
          >
            <div className="flex items-center gap-1.5 font-bold">
              <Mail size={14} className="text-stone-700" />
              <span>Business Email</span>
            </div>
            <span>{ZAVELLO_EMAIL}</span>
          </a>

          <a
            href={ZAVELLO_STORE_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="p-3.5 rounded-xl bg-stone-50 text-stone-900 border border-stone-200 flex flex-col gap-1 hover:bg-stone-100 transition"
          >
            <div className="flex items-center gap-1.5 font-bold">
              <Globe size={14} className="text-sky-700" />
              <span>Website</span>
            </div>
            <span className="flex items-center gap-1">
              {ZAVELLO_STORE_URL}
              <ExternalLink size={11} />
            </span>
          </a>
        </div>
      </div>

    </div>
  );
};
