import React, { useState } from 'react';
import { 
  Heart, 
  ShoppingBag, 
  MessageCircle, 
  Truck, 
  ShieldCheck, 
  ArrowLeft, 
  Check, 
  Plus, 
  Minus, 
  Share2,
  Clock,
  Info,
  ChevronRight
} from 'lucide-react';
import { Product } from '../types';
import { formatPKR } from '../utils/currency';
import { buildProductEnquiryMessage, getWhatsAppUrl, ZAVELLO_WHATSAPP_DISPLAY } from '../services/whatsapp';
import { ProductCard } from '../components/ProductCard';

interface ProductDetailPageProps {
  product: Product;
  allProducts: Product[];
  onBack: () => void;
  onAddToCart: (product: Product, variants: Record<string, string>, quantity: number) => void;
  isWishlisted: boolean;
  onToggleWishlist: (productId: string) => void;
  onSelectProduct: (product: Product) => void;
}

export const ProductDetailPage: React.FC<ProductDetailPageProps> = ({
  product,
  allProducts,
  onBack,
  onAddToCart,
  isWishlisted,
  onToggleWishlist,
  onSelectProduct
}) => {
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [selectedVariants, setSelectedVariants] = useState<Record<string, string>>(() => {
    const initial: Record<string, string> = {};
    if (product.variants) {
      product.variants.forEach(v => {
        if (v.options.length > 0) {
          initial[v.name] = v.options[0];
        }
      });
    }
    return initial;
  });
  const [activeTab, setActiveTab] = useState<'details' | 'shipping' | 'returns'>('details');
  const [addedSuccess, setAddedSuccess] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  const discountPercent = product.compareAtPrice 
    ? Math.round(((product.compareAtPrice - product.price) / product.compareAtPrice) * 100)
    : 0;

  const handleVariantSelect = (variantName: string, option: string) => {
    setSelectedVariants(prev => ({
      ...prev,
      [variantName]: option
    }));
  };

  const handleAdd = () => {
    onAddToCart(product, selectedVariants, quantity);
    setAddedSuccess(true);
    setTimeout(() => setAddedSuccess(false), 2000);
  };

  const handleShare = () => {
    navigator.clipboard?.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  // Related products from the same category
  const relatedProducts = allProducts
    .filter(p => p.category === product.category && p.id !== product.id)
    .slice(0, 3);

  const enquiryMessage = buildProductEnquiryMessage(product.name, product.price, selectedVariants);
  const whatsappUrl = getWhatsAppUrl(enquiryMessage);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 space-y-12">
      
      {/* Breadcrumb / Back button */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-stone-600 hover:text-stone-900 transition"
        >
          <ArrowLeft size={16} />
          <span>Back to Catalog</span>
        </button>

        <button
          onClick={handleShare}
          className="inline-flex items-center gap-1 text-xs text-stone-500 hover:text-stone-800 transition"
        >
          <Share2 size={14} />
          <span>{copiedLink ? 'Link Copied!' : 'Share'}</span>
        </button>
      </div>

      {/* Main Product Showcase */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12">
        
        {/* Images Column */}
        <div className="space-y-3">
          {/* Main Photo */}
          <div className="relative aspect-square sm:aspect-[4/5] bg-stone-100 rounded-2xl overflow-hidden border border-stone-200">
            <img
              src={product.images[activeImageIndex] || product.images[0]}
              alt={product.name}
              className="w-full h-full object-cover object-center"
            />
            {discountPercent > 0 && (
              <span className="absolute top-4 left-4 bg-stone-900 text-stone-50 text-xs font-bold px-2.5 py-1 rounded-md shadow-md">
                SAVE {discountPercent}%
              </span>
            )}
            <button
              onClick={() => onToggleWishlist(product.id)}
              className="absolute top-4 right-4 p-2.5 bg-white/90 backdrop-blur-xs rounded-full text-stone-700 hover:text-rose-500 shadow-md transition"
              aria-label="Wishlist"
            >
              <Heart size={20} className={isWishlisted ? "fill-rose-500 text-rose-500" : ""} />
            </button>
          </div>

          {/* Thumbnails */}
          {product.images.length > 1 && (
            <div className="flex items-center gap-3 overflow-x-auto pb-2">
              {product.images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveImageIndex(idx)}
                  className={`relative w-20 h-20 rounded-xl overflow-hidden border-2 transition shrink-0 ${
                    activeImageIndex === idx ? 'border-stone-900 ring-2 ring-stone-900/20' : 'border-stone-200 opacity-70 hover:opacity-100'
                  }`}
                >
                  <img src={img} alt="" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Product Info & Purchase Actions Column */}
        <div className="flex flex-col justify-between space-y-6">
          <div className="space-y-4">
            
            {/* Category & Badge */}
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-amber-700 bg-amber-50 px-2.5 py-1 rounded">
                {product.categoryLabel}
              </span>
              <span className="text-xs text-stone-500 font-medium flex items-center gap-1">
                <Clock size={13} className="text-emerald-600" />
                <span>Est. Delivery: {product.estimatedDelivery}</span>
              </span>
            </div>

            {/* Name */}
            <h1 className="font-serif-brand text-2xl sm:text-3xl lg:text-4xl font-bold text-stone-900">
              {product.name}
            </h1>

            {/* Price block */}
            <div className="flex items-baseline gap-3 pt-1">
              <span className="text-2xl sm:text-3xl font-extrabold text-stone-900">
                {formatPKR(product.price)}
              </span>
              {product.compareAtPrice && (
                <span className="text-base text-stone-400 line-through">
                  {formatPKR(product.compareAtPrice)}
                </span>
              )}
              <span className="text-xs text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded font-semibold">
                Cash on Delivery Available
              </span>
            </div>

            {/* Honest Availability Notice */}
            <div className="p-3 bg-stone-100 rounded-xl border border-stone-200/80 text-xs space-y-1">
              <div className="flex items-center gap-1.5 font-semibold text-stone-800">
                <Info size={14} className="text-amber-700" />
                <span>Stock & Fulfillment Status:</span>
              </div>
              <p className="text-stone-600">
                {product.availabilityNote}
              </p>
            </div>

            {/* Description brief */}
            <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">
              {product.description}
            </p>

            {/* Variants Selector */}
            {product.variants && product.variants.map((variant) => (
              <div key={variant.name} className="space-y-2 pt-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-stone-900">{variant.name}:</span>
                  <span className="text-stone-600 font-medium">{selectedVariants[variant.name]}</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {variant.options.map((opt) => {
                    const isSelected = selectedVariants[variant.name] === opt;
                    return (
                      <button
                        key={opt}
                        type="button"
                        onClick={() => handleVariantSelect(variant.name, opt)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition border ${
                          isSelected
                            ? 'bg-stone-900 text-white border-stone-900 shadow-xs'
                            : 'bg-white text-stone-700 border-stone-200 hover:border-stone-400'
                        }`}
                      >
                        {opt}
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}

            {/* Quantity Selector */}
            <div className="pt-2">
              <label className="block text-xs font-bold text-stone-900 mb-2">
                Quantity:
              </label>
              <div className="inline-flex items-center border border-stone-300 rounded-lg bg-white">
                <button
                  type="button"
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="p-2 text-stone-600 hover:bg-stone-100 transition rounded-l-lg"
                  aria-label="Decrease"
                >
                  <Minus size={14} />
                </button>
                <span className="px-4 text-xs font-bold text-stone-900 min-w-8 text-center">
                  {quantity}
                </span>
                <button
                  type="button"
                  onClick={() => setQuantity(quantity + 1)}
                  className="p-2 text-stone-600 hover:bg-stone-100 transition rounded-r-lg"
                  aria-label="Increase"
                >
                  <Plus size={14} />
                </button>
              </div>
            </div>

          </div>

          {/* Action Buttons: Add to Bag + WhatsApp Enquiry */}
          <div className="space-y-2.5 pt-4 border-t border-stone-200">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                type="button"
                onClick={handleAdd}
                className={`w-full py-3.5 px-6 rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition shadow-sm ${
                  addedSuccess
                    ? 'bg-emerald-600 text-white'
                    : 'bg-stone-900 hover:bg-stone-800 text-white'
                }`}
              >
                {addedSuccess ? (
                  <>
                    <Check size={18} />
                    <span>Added to Bag!</span>
                  </>
                ) : (
                  <>
                    <ShoppingBag size={18} />
                    <span>Add to Bag ({formatPKR(product.price * quantity)})</span>
                  </>
                )}
              </button>

              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3.5 px-6 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition shadow-sm"
              >
                <MessageCircle size={18} />
                <span>WhatsApp Order / Query</span>
              </a>
            </div>

            <p className="text-[11px] text-stone-500 text-center">
              Direct human support on WhatsApp ({ZAVELLO_WHATSAPP_DISPLAY}). No payment needed upfront.
            </p>
          </div>

          {/* Highlights Checklist */}
          <div className="grid grid-cols-2 gap-3 pt-3 border-t border-stone-100 text-xs text-stone-600">
            <div className="flex items-center gap-2">
              <Truck size={16} className="text-stone-800" />
              <span>Nationwide Pakistan Courier</span>
            </div>
            <div className="flex items-center gap-2">
              <ShieldCheck size={16} className="text-emerald-700" />
              <span>Pay on Doorstep (COD)</span>
            </div>
          </div>

        </div>

      </div>

      {/* Tabs: Details, Shipping in Pakistan, Returns */}
      <div className="bg-white rounded-2xl border border-stone-200 p-6 sm:p-8 space-y-6">
        <div className="flex border-b border-stone-200 gap-6">
          <button
            onClick={() => setActiveTab('details')}
            className={`pb-3 text-xs sm:text-sm font-bold transition border-b-2 ${
              activeTab === 'details'
                ? 'border-stone-900 text-stone-900'
                : 'border-transparent text-stone-400 hover:text-stone-700'
            }`}
          >
            Product Features & Details
          </button>
          <button
            onClick={() => setActiveTab('shipping')}
            className={`pb-3 text-xs sm:text-sm font-bold transition border-b-2 ${
              activeTab === 'shipping'
                ? 'border-stone-900 text-stone-900'
                : 'border-transparent text-stone-400 hover:text-stone-700'
            }`}
          >
            Pakistan Delivery Timelines
          </button>
          <button
            onClick={() => setActiveTab('returns')}
            className={`pb-3 text-xs sm:text-sm font-bold transition border-b-2 ${
              activeTab === 'returns'
                ? 'border-stone-900 text-stone-900'
                : 'border-transparent text-stone-400 hover:text-stone-700'
            }`}
          >
            Inspection & Returns
          </button>
        </div>

        {activeTab === 'details' && (
          <div className="space-y-4 text-xs sm:text-sm text-stone-700">
            <p className="leading-relaxed">{product.description}</p>
            {product.features && product.features.length > 0 && (
              <div className="space-y-2 pt-2">
                <h4 className="font-bold text-stone-900">Key Features:</h4>
                <ul className="list-disc pl-5 space-y-1 text-stone-600">
                  {product.features.map((feat, i) => (
                    <li key={i}>{feat}</li>
                  ))}
                </ul>
              </div>
            )}
            {product.sku && (
              <p className="text-stone-400 text-xs pt-2">
                Reference Code: <span className="font-mono">{product.sku}</span>
              </p>
            )}
          </div>
        )}

        {activeTab === 'shipping' && (
          <div className="space-y-3 text-xs sm:text-sm text-stone-700">
            <p className="leading-relaxed">
              We deliver to all cities, cantts, and districts in Pakistan through verified courier networks (TCS, Leopard, Trax, PostEx).
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs bg-stone-50 p-4 rounded-xl border border-stone-200">
              <div>
                <strong>Major Metropolitan Cities:</strong><br />
                Karachi, Lahore, Islamabad, Rawalpindi, Faisalabad: <strong>2-3 business days</strong>
              </div>
              <div>
                <strong>Other Cities & Regional Towns:</strong><br />
                Multan, Peshawar, Quetta, Sialkot, Hyderabad, etc.: <strong>3-5 business days</strong>
              </div>
            </div>
            <p className="text-[11px] text-stone-500">
              Delivery charge: <strong>FREE</strong> for orders above Rs. 3,000. Flat Rs. 250 for orders below Rs. 3,000.
            </p>
          </div>
        )}

        {activeTab === 'returns' && (
          <div className="space-y-3 text-xs sm:text-sm text-stone-700">
            <h4 className="font-bold text-stone-900">Customer Satisfaction & Return Policy:</h4>
            <p className="leading-relaxed">
              We stand behind genuine products. If an item arrives damaged, defective, or different from described, notify us on WhatsApp (+92 325 9380039) within <strong>7 days</strong> with unboxing photos or video.
            </p>
            <p className="text-stone-600">
              Personal care, cosmetics, and opened intimate accessories cannot be returned once unsealed for hygiene reasons.
            </p>
          </div>
        )}
      </div>

      {/* Related Products */}
      {relatedProducts.length > 0 && (
        <div className="space-y-6 pt-4">
          <div className="flex items-center justify-between">
            <h3 className="font-serif-brand text-xl sm:text-2xl font-bold text-stone-900">
              You May Also Like
            </h3>
            <button
              onClick={() => onSelectProduct(relatedProducts[0])}
              className="text-xs font-semibold text-stone-700 hover:text-stone-950 flex items-center gap-1"
            >
              <span>Explore</span>
              <ChevronRight size={14} />
            </button>
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
            {relatedProducts.map(p => (
              <ProductCard
                key={p.id}
                product={p}
                onSelectProduct={onSelectProduct}
                onQuickAddToCart={(prod) => onAddToCart(prod, {}, 1)}
                isWishlisted={isWishlisted}
                onToggleWishlist={onToggleWishlist}
              />
            ))}
          </div>
        </div>
      )}

    </div>
  );
};
