import React from 'react';
import { 
  ArrowRight, 
  Sparkles, 
  Truck, 
  ShieldCheck, 
  MessageCircle, 
  ShoppingBag,
  HeartHandshake,
  CheckCircle2,
  Package
} from 'lucide-react';
import { Product, ProductCategory } from '../types';
import { ProductCard } from '../components/ProductCard';
import { CATEGORIES_CONFIG } from '../data/products';
import { getWhatsAppUrl } from '../services/whatsapp';

interface HomePageProps {
  products: Product[];
  onSelectProduct: (product: Product) => void;
  onQuickAddToCart: (product: Product) => void;
  wishlist: string[];
  onToggleWishlist: (productId: string) => void;
  onSelectCategory: (category: ProductCategory | 'all') => void;
  onNavigateToShop: () => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  products,
  onSelectProduct,
  onQuickAddToCart,
  wishlist,
  onToggleWishlist,
  onSelectCategory,
  onNavigateToShop
}) => {
  const featuredProducts = products.filter(p => p.featured).slice(0, 4);
  const newArrivals = products.filter(p => p.isNew).slice(0, 4);
  const popularProducts = products.filter(p => p.isPopular).slice(0, 4);

  return (
    <div className="space-y-12 sm:space-y-16 pb-12">
      
      {/* Hero Banner Section */}
      <section className="relative bg-stone-900 text-stone-100 overflow-hidden rounded-2xl mx-4 sm:mx-6 lg:mx-8 mt-4 shadow-xl">
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=1600&q=80"
            alt="Zavello Market Hero"
            className="w-full h-full object-cover object-center opacity-30 mix-blend-overlay"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-stone-950 via-stone-900/90 to-transparent" />
        </div>

        <div className="relative z-10 max-w-3xl px-6 py-14 sm:py-20 lg:py-24 sm:px-12 flex flex-col items-start">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-semibold uppercase tracking-wider mb-4">
            <Sparkles size={13} className="text-amber-400" />
            <span>Curated For Pakistan • Cash on Delivery</span>
          </div>

          <h1 className="font-serif-brand text-3xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-white leading-tight">
            Elevate Your Everyday Style & Living.
          </h1>

          <p className="mt-4 text-sm sm:text-base text-stone-300 max-w-xl leading-relaxed">
            Discover handpicked fashion, beauty, skincare, accessories, and aesthetic lifestyle essentials. Fast delivery across Pakistan with verified WhatsApp ordering.
          </p>

          {/* Action buttons */}
          <div className="mt-8 flex flex-wrap items-center gap-3 w-full sm:w-auto">
            <button
              onClick={onNavigateToShop}
              className="w-full sm:w-auto px-6 py-3.5 bg-white hover:bg-stone-100 text-stone-900 text-sm font-bold rounded-xl transition shadow-md flex items-center justify-center gap-2"
            >
              <span>Explore Collection</span>
              <ArrowRight size={16} />
            </button>

            <a
              href={getWhatsAppUrl("Hello Zavello Market! I'd like to check product availability.")}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto px-5 py-3.5 bg-emerald-600/90 hover:bg-emerald-600 text-white text-sm font-semibold rounded-xl transition flex items-center justify-center gap-2 border border-emerald-500/40"
            >
              <MessageCircle size={16} />
              <span>Order via WhatsApp</span>
            </a>
          </div>

          {/* Mini trust checklist */}
          <div className="mt-8 pt-6 border-t border-stone-800/80 flex flex-wrap items-center gap-4 text-xs text-stone-400">
            <span className="flex items-center gap-1.5">
              <CheckCircle2 size={14} className="text-emerald-400" />
              <span>Nationwide TCS / Trax Courier</span>
            </span>
            <span className="flex items-center gap-1.5">
              <CheckCircle2 size={14} className="text-emerald-400" />
              <span>Cash on Delivery</span>
            </span>
            <span className="flex items-center gap-1.5">
              <CheckCircle2 size={14} className="text-emerald-400" />
              <span>Honest Supplier Sourcing</span>
            </span>
          </div>
        </div>
      </section>

      {/* Categories Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-end justify-between mb-6">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-amber-700">Categories</span>
            <h2 className="font-serif-brand text-2xl sm:text-3xl font-bold text-stone-900 mt-1">
              Shop by Department
            </h2>
          </div>
          <button
            onClick={() => onSelectCategory('all')}
            className="text-xs font-semibold text-stone-900 hover:text-stone-600 flex items-center gap-1 transition"
          >
            <span>View All</span>
            <ArrowRight size={14} />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 sm:gap-4">
          {CATEGORIES_CONFIG.map((category) => (
            <button
              key={category.id}
              onClick={() => onSelectCategory(category.id)}
              className="group p-4 bg-white rounded-xl border border-stone-200/80 hover:border-stone-400 hover:shadow-md transition-all text-left flex flex-col justify-between"
            >
              <div>
                <span className="text-xl sm:text-2xl mb-2 block">
                  {category.id === 'fashion' && '👗'}
                  {category.id === 'beauty' && '💄'}
                  {category.id === 'body-care' && '🧴'}
                  {category.id === 'accessories' && '👜'}
                  {category.id === 'lifestyle' && '🕯️'}
                </span>
                <h3 className="font-bold text-stone-900 text-sm group-hover:text-amber-800 transition">
                  {category.name}
                </h3>
                <p className="text-[11px] text-stone-500 mt-1 line-clamp-2">
                  {category.desc}
                </p>
              </div>
              <div className="mt-3 flex items-center justify-between text-[11px] font-semibold text-stone-700 group-hover:text-stone-950 pt-2 border-t border-stone-100">
                <span>Browse</span>
                <ArrowRight size={12} className="group-hover:translate-x-0.5 transition-transform" />
              </div>
            </button>
          ))}
        </div>
      </section>

      {/* Featured Products Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-end justify-between mb-6">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-amber-700">Handpicked</span>
            <h2 className="font-serif-brand text-2xl sm:text-3xl font-bold text-stone-900 mt-1">
              Featured Highlights
            </h2>
          </div>
          <button
            onClick={onNavigateToShop}
            className="text-xs font-semibold text-stone-900 hover:text-stone-600 flex items-center gap-1 transition"
          >
            <span>See more</span>
            <ArrowRight size={14} />
          </button>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-6">
          {featuredProducts.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onSelectProduct={onSelectProduct}
              onQuickAddToCart={onQuickAddToCart}
              isWishlisted={wishlist.includes(product.id)}
              onToggleWishlist={onToggleWishlist}
            />
          ))}
        </div>
      </section>

      {/* Honest Supplier Fulfillment & Pakistan Cash on Delivery Reassurance */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-stone-100 rounded-2xl p-6 sm:p-8 border border-stone-200">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
            
            <div className="md:col-span-2 space-y-3">
              <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-stone-600">
                <HeartHandshake size={16} className="text-amber-700" />
                <span>Our Transparent Service Pledge</span>
              </div>
              <h3 className="font-serif-brand text-xl sm:text-2xl font-bold text-stone-900">
                Honest Fulfillment & Risk-Free Cash on Delivery
              </h3>
              <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">
                At Zavello Market, we value your trust above all else. We partner with vetted fashion workshops, cosmetics distributors, and lifestyle artisans across Pakistan. Before collecting payment, we verify live supplier inventory upon your WhatsApp order submission, ensuring you only receive genuine, freshly inspected items.
              </p>
            </div>

            <div className="bg-white p-4 rounded-xl border border-stone-200/80 shadow-xs space-y-2.5 text-xs">
              <div className="font-semibold text-stone-900 flex items-center gap-2">
                <Package size={16} className="text-emerald-600" />
                <span>Standard Delivery Windows:</span>
              </div>
              <p className="text-stone-600 text-[11px]">
                • Major Cities (Lahore, Karachi, Islamabad): <strong>2-3 Days</strong><br />
                • Other Cities & Regional Towns: <strong>3-5 Days</strong><br />
                • Pay cash directly to courier rider upon inspection.
              </p>
              <a
                href={getWhatsAppUrl("Hello! I have a question regarding delivery timelines and stock.")}
                target="_blank"
                rel="noopener noreferrer"
                className="block text-center py-2 px-3 bg-stone-900 hover:bg-stone-800 text-white rounded-lg font-semibold text-xs transition"
              >
                Inquire on WhatsApp
              </a>
            </div>

          </div>
        </div>
      </section>

      {/* New Arrivals Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-end justify-between mb-6">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-amber-700">Fresh Stock</span>
            <h2 className="font-serif-brand text-2xl sm:text-3xl font-bold text-stone-900 mt-1">
              New Arrivals
            </h2>
          </div>
          <button
            onClick={onNavigateToShop}
            className="text-xs font-semibold text-stone-900 hover:text-stone-600 flex items-center gap-1 transition"
          >
            <span>View All</span>
            <ArrowRight size={14} />
          </button>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-6">
          {newArrivals.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onSelectProduct={onSelectProduct}
              onQuickAddToCart={onQuickAddToCart}
              isWishlisted={wishlist.includes(product.id)}
              onToggleWishlist={onToggleWishlist}
            />
          ))}
        </div>
      </section>

      {/* Popular Products */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-end justify-between mb-6">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-amber-700">Most Loved</span>
            <h2 className="font-serif-brand text-2xl sm:text-3xl font-bold text-stone-900 mt-1">
              Customer Favorites
            </h2>
          </div>
          <button
            onClick={onNavigateToShop}
            className="text-xs font-semibold text-stone-900 hover:text-stone-600 flex items-center gap-1 transition"
          >
            <span>Explore All</span>
            <ArrowRight size={14} />
          </button>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-6">
          {popularProducts.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onSelectProduct={onSelectProduct}
              onQuickAddToCart={onQuickAddToCart}
              isWishlisted={wishlist.includes(product.id)}
              onToggleWishlist={onToggleWishlist}
            />
          ))}
        </div>
      </section>

      {/* WhatsApp VIP Club Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-stone-900 text-stone-100 rounded-2xl p-6 sm:p-10 relative overflow-hidden">
          <div className="relative z-10 max-w-xl space-y-3">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-400">
              Personalized Shopping Assistance
            </span>
            <h3 className="font-serif-brand text-2xl sm:text-3xl font-bold text-white">
              Need Help Finding a Size or Shade?
            </h3>
            <p className="text-xs sm:text-sm text-stone-300 leading-relaxed">
              Our Pakistan support desk is active on WhatsApp. Send us photos of items you are looking for, ask for fabric measurements, or check custom bulk pricing.
            </p>
            <div className="pt-2">
              <a
                href={getWhatsAppUrl("Hello Zavello Market! I would like some shopping advice.")}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-5 py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition shadow-md"
              >
                <MessageCircle size={16} />
                <span>Chat with Personal Stylist (+92 325 9380039)</span>
              </a>
            </div>
          </div>
        </div>
      </section>

    </div>
  );
};
