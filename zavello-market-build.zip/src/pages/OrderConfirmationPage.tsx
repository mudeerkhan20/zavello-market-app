import React, { useState } from 'react';
import { 
  CheckCircle, 
  MessageCircle, 
  Copy, 
  Check, 
  ArrowRight, 
  Clock, 
  AlertCircle, 
  Package, 
  ExternalLink,
  Phone
} from 'lucide-react';
import { OrderSubmission } from '../types';
import { formatPKR } from '../utils/currency';
import { 
  getWhatsAppUrl, 
  ZAVELLO_WHATSAPP_DISPLAY, 
  ZAVELLO_EMAIL 
} from '../services/whatsapp';

interface OrderConfirmationPageProps {
  order: OrderSubmission;
  onContinueShopping: () => void;
}

export const OrderConfirmationPage: React.FC<OrderConfirmationPageProps> = ({
  order,
  onContinueShopping
}) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard?.writeText(order.whatsappMessage);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const whatsappUrl = getWhatsAppUrl(order.whatsappMessage);

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8 sm:py-12 space-y-8">
      
      {/* Status Header Box */}
      <div className="bg-white rounded-2xl border border-stone-200 p-6 sm:p-8 text-center space-y-4 shadow-sm">
        
        <div className="w-16 h-16 rounded-full bg-amber-50 border border-amber-200 text-amber-600 flex items-center justify-center mx-auto">
          <Clock size={32} />
        </div>

        <div>
          <span className="inline-block px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-amber-100 text-amber-900 mb-2">
            Status: Awaiting WhatsApp Confirmation
          </span>
          <h1 className="font-serif-brand text-2xl sm:text-3xl font-bold text-stone-900">
            Your Order Request Has Been Prepared
          </h1>
          <p className="text-xs sm:text-sm text-stone-600 max-w-lg mx-auto mt-2 leading-relaxed">
            Provisional Reference: <strong className="font-mono text-stone-900">#{order.provisionalId}</strong>
          </p>
        </div>

        {/* Essential Transparent Disclosure */}
        <div className="p-4 bg-amber-50/90 border border-amber-200 rounded-xl text-left text-xs text-amber-950 space-y-2">
          <div className="flex items-center gap-2 font-bold text-amber-900">
            <AlertCircle size={16} className="text-amber-700 shrink-0" />
            <span>Important Notice Regarding Your Order:</span>
          </div>
          <p className="leading-relaxed">
            Opening or preparing WhatsApp does <strong>not</strong> mean the order is automatically finalized or saved to a server. 
            To complete your order, <strong>please press "Send" in your WhatsApp chat</strong> with Zavello Market. 
            Our team will verify supplier stock in Pakistan, check delivery scheduling, and reply to confirm your package.
          </p>
        </div>

        {/* Action Buttons: Open WhatsApp & Copy Text */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full sm:w-auto px-6 py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition shadow-md"
          >
            <MessageCircle size={18} />
            <span>Open WhatsApp with Zavello Market</span>
          </a>

          <button
            type="button"
            onClick={handleCopy}
            className={`w-full sm:w-auto px-5 py-3.5 rounded-xl text-xs sm:text-sm font-semibold flex items-center justify-center gap-2 border transition ${
              copied
                ? 'bg-stone-100 text-emerald-700 border-emerald-300'
                : 'bg-white text-stone-800 border-stone-300 hover:bg-stone-50'
            }`}
          >
            {copied ? (
              <>
                <Check size={16} />
                <span>Order Text Copied to Clipboard!</span>
              </>
            ) : (
              <>
                <Copy size={16} />
                <span>Copy Order Message Text</span>
              </>
            )}
          </button>
        </div>

      </div>

      {/* Itemized Order Summary */}
      <div className="bg-white rounded-2xl border border-stone-200 p-6 sm:p-8 space-y-6 shadow-xs">
        <h2 className="font-bold text-stone-900 text-base sm:text-lg border-b border-stone-100 pb-3 flex items-center gap-2">
          <Package size={20} className="text-stone-700" />
          <span>Itemized Request Breakdown</span>
        </h2>

        {/* Customer Snapshot */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs bg-stone-50 p-4 rounded-xl border border-stone-200">
          <div>
            <span className="text-stone-400 uppercase text-[10px] font-bold block mb-0.5">Customer</span>
            <strong className="text-stone-900">{order.customer.fullName}</strong>
            <p className="text-stone-600 mt-0.5">{order.customer.phone}</p>
          </div>
          <div>
            <span className="text-stone-400 uppercase text-[10px] font-bold block mb-0.5">Shipping Destination</span>
            <strong className="text-stone-900">{order.customer.city}, Pakistan</strong>
            <p className="text-stone-600 mt-0.5">{order.customer.address}</p>
          </div>
        </div>

        {/* Items List */}
        <div className="divide-y divide-stone-100">
          {order.items.map((item) => (
            <div key={item.id} className="py-3.5 flex items-center justify-between gap-4">
              <div className="flex items-center gap-3 min-w-0">
                <img
                  src={item.product.images[0]}
                  alt={item.product.name}
                  className="w-14 h-16 object-cover rounded-lg bg-stone-100 shrink-0"
                />
                <div className="min-w-0">
                  <h4 className="text-xs sm:text-sm font-semibold text-stone-900 truncate">
                    {item.product.name}
                  </h4>
                  {Object.keys(item.selectedVariants).length > 0 && (
                    <p className="text-[11px] text-stone-500">
                      {Object.entries(item.selectedVariants).map(([k, v]) => `${k}: ${v}`).join(' | ')}
                    </p>
                  )}
                  <p className="text-xs text-stone-500">
                    Quantity: {item.quantity} × {formatPKR(item.unitPrice)}
                  </p>
                </div>
              </div>
              <span className="text-xs sm:text-sm font-bold text-stone-900 shrink-0">
                {formatPKR(item.unitPrice * item.quantity)}
              </span>
            </div>
          ))}
        </div>

        {/* Totals */}
        <div className="border-t border-stone-200 pt-4 space-y-2 text-xs">
          <div className="flex justify-between text-stone-600">
            <span>Items Subtotal</span>
            <span className="font-semibold text-stone-900">{formatPKR(order.subtotal)}</span>
          </div>
          <div className="flex justify-between text-stone-600">
            <span>Nationwide Delivery</span>
            <span className="font-semibold text-stone-900">
              {order.shippingFee === 0 ? (
                <span className="text-emerald-700 uppercase font-bold">Free</span>
              ) : (
                formatPKR(order.shippingFee)
              )}
            </span>
          </div>
          <div className="border-t border-stone-100 pt-2 flex justify-between text-base font-extrabold text-stone-900">
            <span>Estimated Total (PKR)</span>
            <span>{formatPKR(order.total)}</span>
          </div>
          <div className="text-[11px] text-stone-500 flex justify-between pt-1">
            <span>Requested Payment:</span>
            <span className="font-medium text-stone-700 capitalize">
              {order.customer.paymentMethod.replace(/_/g, ' ')}
            </span>
          </div>
        </div>

        {/* Message preview block for fallback */}
        <div className="space-y-2 pt-2">
          <label className="block text-xs font-bold text-stone-700">
            WhatsApp Message Content (for reference or manual copy):
          </label>
          <pre className="p-3 bg-stone-900 text-stone-200 text-[11px] rounded-xl whitespace-pre-wrap font-mono max-h-48 overflow-y-auto">
            {order.whatsappMessage}
          </pre>
        </div>

        {/* Return Button */}
        <div className="pt-4 border-t border-stone-100 flex flex-col sm:flex-row items-center justify-between gap-3">
          <button
            onClick={onContinueShopping}
            className="w-full sm:w-auto px-6 py-3 bg-stone-900 hover:bg-stone-800 text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition"
          >
            <span>Return to Shopping</span>
            <ArrowRight size={14} />
          </button>

          <div className="text-xs text-stone-500 flex items-center gap-2">
            <Phone size={14} className="text-emerald-600" />
            <span>Support: {ZAVELLO_WHATSAPP_DISPLAY}</span>
          </div>
        </div>

      </div>

    </div>
  );
};
