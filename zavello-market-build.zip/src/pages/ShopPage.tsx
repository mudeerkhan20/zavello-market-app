import React, { useState, useMemo } from 'react';
import { 
  Filter, 
  X, 
  Search, 
  SlidersHorizontal, 
  Check, 
  RotateCcw,
  ShoppingBag
} from 'lucide-react';
import { Product, ProductCategory } from '../types';
import { ProductCard } from '../components/ProductCard';
import { formatPKR } from '../utils/currency';

interface ShopPageProps {
  products: Product[];
  selectedCategory: ProductCategory | 'all';
  setSelectedCategory: (cat: ProductCategory | 'all') => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  onSelectProduct: (product: Product) => void;
  onQuickAddToCart: (product: Product) => void;
  wishlist: string[];
  onToggleWishlist: (productId: string) => void;
}

type SortOption = 'featured' | 'newest' | 'price-asc' | 'price-desc' | 'popular';

export const ShopPage: React.FC<ShopPageProps> = ({
  products,
  selectedCategory,
  setSelectedCategory,
  searchQuery,
  setSearchQuery,
  onSelectProduct,
  onQuickAddToCart,
  wishlist,
  onToggleWishlist
}) => {
  const [sortBy, setSortBy] = useState<SortOption>('featured');
  const [maxPrice, setMaxPrice] = useState<number>(6000);
  const [onlyInStock, setOnlyInStock] = useState<boolean>(false);
  const [mobileFilterOpen, setMobileFilterOpen] = useState<boolean>(false);

  const categoriesList: { id: ProductCategory | 'all'; label: string }[] = [
    { id: 'all', label: 'All Categories' },
    { id: 'fashion', label: 'Fashion & Apparel' },
    { id: 'beauty', label: 'Beauty & Cosmetics' },
    { id: 'body-care', label: 'Body Care' },
    { id: 'accessories', label: 'Accessories' },
    { id: 'lifestyle', label: 'Lifestyle' },
  ];

  // Filter & sort logic
  const filteredProducts = useMemo(() => {
    return products
      .filter((p) => {
        // Category filter
        if (selectedCategory !== 'all' && p.category !== selectedCategory) {
          return false;
        }

        // Price filter
        if (p.price > maxPrice) {
          return false;
        }

        // Search query
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase().trim();
          const matchesName = p.name.toLowerCase().includes(q);
          const matchesDesc = p.description.toLowerCase().includes(q);
          const matchesCategory = p.categoryLabel.toLowerCase().includes(q);
          if (!matchesName && !matchesDesc && !matchesCategory) {
            return false;
          }
        }

        // In-stock toggle
        if (onlyInStock && p.availability === 'out_of_stock') {
          return false;
        }

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'price-asc') return a.price - b.price;
        if (sortBy === 'price-desc') return b.price - a.price;
        if (sortBy === 'newest') return (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0);
        if (sortBy === 'popular') return (b.isPopular ? 1 : 0) - (a.isPopular ? 1 : 0);
        return (b.featured ? 1 : 0) - (a.featured ? 1 : 0);
      });
  }, [products, selectedCategory, maxPrice, searchQuery, onlyInStock, sortBy]);

  const resetFilters = () => {
    setSelectedCategory('all');
    setSearchQuery('');
    setMaxPrice(6000);
    setOnlyInStock(false);
    setSortBy('featured');
  };

  const hasActiveFilters = selectedCategory !== 'all' || searchQuery !== '' || maxPrice < 6000 || onlyInStock;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
      
      {/* Title & Mobile Filter Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-stone-200">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-amber-700">
            Catalog
          </span>
          <h1 className="font-serif-brand text-2xl sm:text-3xl font-bold text-stone-900 mt-0.5">
            {selectedCategory === 'all' 
              ? 'All Products' 
              : categoriesList.find(c => c.id === selectedCategory)?.label}
          </h1>
          <p className="text-xs text-stone-500 mt-1">
            Showing {filteredProducts.length} curated products • Prices in Pakistani Rupee (PKR)
          </p>
        </div>

        {/* Sort & Mobile Filter Toggle */}
        <div className="flex items-center gap-2.5 self-start sm:self-auto">
          <button
            onClick={() => setMobileFilterOpen(!mobileFilterOpen)}
            className="lg:hidden flex items-center gap-1.5 px-3 py-2 bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-semibold rounded-lg transition"
          >
            <SlidersHorizontal size={14} />
            <span>Filters</span>
            {hasActiveFilters && (
              <span className="w-2 h-2 rounded-full bg-amber-600"></span>
            )}
          </button>

          <div className="flex items-center gap-2">
            <span className="text-xs text-stone-500 hidden sm:inline">Sort:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as SortOption)}
              className="bg-stone-100 border border-stone-200 text-stone-800 text-xs font-medium rounded-lg px-2.5 py-2 focus:outline-none focus:ring-1 focus:ring-stone-400 cursor-pointer"
            >
              <option value="featured">Featured First</option>
              <option value="popular">Popular Picks</option>
              <option value="newest">New Arrivals</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
            </select>
          </div>
        </div>
      </div>

      {/* Active Filter Chips */}
      {hasActiveFilters && (
        <div className="flex flex-wrap items-center gap-2 pt-4 pb-2">
          <span className="text-xs font-medium text-stone-500">Active filters:</span>
          
          {selectedCategory !== 'all' && (
            <span className="inline-flex items-center gap-1 text-xs bg-stone-200/80 text-stone-800 px-2.5 py-1 rounded-full">
              Category: {categoriesList.find(c => c.id === selectedCategory)?.label}
              <button onClick={() => setSelectedCategory('all')}>
                <X size={12} />
              </button>
            </span>
          )}

          {searchQuery && (
            <span className="inline-flex items-center gap-1 text-xs bg-stone-200/80 text-stone-800 px-2.5 py-1 rounded-full">
              Search: "{searchQuery}"
              <button onClick={() => setSearchQuery('')}>
                <X size={12} />
              </button>
            </span>
          )}

          {maxPrice < 6000 && (
            <span className="inline-flex items-center gap-1 text-xs bg-stone-200/80 text-stone-800 px-2.5 py-1 rounded-full">
              Max: {formatPKR(maxPrice)}
              <button onClick={() => setMaxPrice(6000)}>
                <X size={12} />
              </button>
            </span>
          )}

          {onlyInStock && (
            <span className="inline-flex items-center gap-1 text-xs bg-stone-200/80 text-stone-800 px-2.5 py-1 rounded-full">
              In Stock Only
              <button onClick={() => setOnlyInStock(false)}>
                <X size={12} />
              </button>
            </span>
          )}

          <button
            onClick={resetFilters}
            className="text-xs text-rose-600 hover:text-rose-800 font-semibold underline ml-1"
          >
            Clear all
          </button>
        </div>
      )}

      {/* Main Layout: Sidebar Filters + Products Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 pt-6">
        
        {/* Desktop Sidebar Filters */}
        <aside className={`lg:block ${mobileFilterOpen ? 'block' : 'hidden'} space-y-6 bg-white lg:bg-transparent p-5 lg:p-0 rounded-xl border lg:border-0 border-stone-200`}>
          
          {/* Search box inside filter */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-stone-900 mb-2">
              Search Catalog
            </label>
            <div className="relative">
              <input
                type="text"
                placeholder="Product, brand, fabric..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-8 pr-3 py-2 text-xs bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-stone-400"
              />
              <Search size={14} className="absolute left-2.5 top-2.5 text-stone-400" />
            </div>
          </div>

          {/* Category List */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-stone-900 mb-2">
              Categories
            </label>
            <div className="space-y-1">
              {categoriesList.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-medium transition flex items-center justify-between ${
                    selectedCategory === cat.id
                      ? 'bg-stone-900 text-white font-semibold'
                      : 'text-stone-700 hover:bg-stone-100'
                  }`}
                >
                  <span>{cat.label}</span>
                  {selectedCategory === cat.id && <Check size={13} />}
                </button>
              ))}
            </div>
          </div>

          {/* Price Range */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-bold uppercase tracking-wider text-stone-900">
                Max Price
              </label>
              <span className="text-xs font-semibold text-stone-900">
                {formatPKR(maxPrice)}
              </span>
            </div>
            <input
              type="range"
              min="1000"
              max="6000"
              step="250"
              value={maxPrice}
              onChange={(e) => setMaxPrice(Number(e.target.value))}
              className="w-full accent-stone-900 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-stone-400 mt-1">
              <span>Rs. 1,000</span>
              <span>Rs. 6,000+</span>
            </div>
          </div>

          {/* Availability checkbox */}
          <div className="pt-2 border-t border-stone-100">
            <label className="flex items-center gap-2 cursor-pointer text-xs text-stone-700">
              <input
                type="checkbox"
                checked={onlyInStock}
                onChange={(e) => setOnlyInStock(e.target.checked)}
                className="rounded text-stone-900 focus:ring-stone-400 accent-stone-900"
              />
              <span>In-stock / Immediate dispatch only</span>
            </label>
          </div>

          {/* Reset Filters */}
          {hasActiveFilters && (
            <button
              onClick={resetFilters}
              className="w-full flex items-center justify-center gap-1.5 py-2 text-xs font-semibold text-stone-700 hover:text-stone-900 border border-stone-200 rounded-lg hover:bg-stone-50 transition"
            >
              <RotateCcw size={13} />
              <span>Reset All Filters</span>
            </button>
          )}

          {/* Honest Note */}
          <div className="p-3 bg-stone-50 border border-stone-200 rounded-lg text-[11px] text-stone-500 leading-relaxed">
            <strong className="text-stone-700 block mb-0.5">Supplier Fulfillment:</strong>
            Stock is confirmed live with our partners before packaging. Zero hidden charges.
          </div>
        </aside>

        {/* Product Grid */}
        <main className="lg:col-span-3">
          {filteredProducts.length === 0 ? (
            <div className="bg-white rounded-xl border border-stone-200 p-12 text-center flex flex-col items-center justify-center">
              <div className="w-16 h-16 rounded-full bg-stone-100 flex items-center justify-center text-stone-400 mb-4">
                <ShoppingBag size={28} className="stroke-1" />
              </div>
              <h3 className="font-serif-brand text-lg font-bold text-stone-800">
                No matching products found
              </h3>
              <p className="text-xs text-stone-500 mt-1 max-w-sm">
                Try adjusting your search terms, changing the category, or expanding your price range.
              </p>
              <button
                onClick={resetFilters}
                className="mt-5 px-5 py-2 bg-stone-900 hover:bg-stone-800 text-white rounded-lg text-xs font-semibold transition"
              >
                Reset All Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-6">
              {filteredProducts.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onSelectProduct={onSelectProduct}
                  onQuickAddToCart={onQuickAddToCart}
                  isWishlisted={wishlist.includes(product.id)}
                  onToggleWishlist={onToggleWishlist}
                />
              ))}
            </div>
          )}
        </main>

      </div>
    </div>
  );
};
