import React from 'react';
import { Heart, ShoppingBag, Trash2, ArrowLeft } from 'lucide-react';
import { Product } from '../types';
import { formatPKR } from '../utils/currency';

interface WishlistPageProps {
  wishlistIds: string[];
  allProducts: Product[];
  onRemoveFromWishlist: (productId: string) => void;
  onClearWishlist: () => void;
  onAddToCart: (product: Product) => void;
  onSelectProduct: (product: Product) => void;
  onContinueShopping: () => void;
}

export const WishlistPage: React.FC<WishlistPageProps> = ({
  wishlistIds,
  allProducts,
  onRemoveFromWishlist,
  onClearWishlist,
  onAddToCart,
  onSelectProduct,
  onContinueShopping
}) => {
  const wishlistedProducts = allProducts.filter(p => wishlistIds.includes(p.id));

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 space-y-8">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-stone-200">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-amber-700">Favorites</span>
          <h1 className="font-serif-brand text-2xl sm:text-3xl font-bold text-stone-900 mt-0.5">
            My Wishlist ({wishlistedProducts.length})
          </h1>
          <p className="text-xs text-stone-500 mt-1">
            *Wishlist is saved locally in your current browser. Sign-in cloud sync planned for future release.
          </p>
        </div>

        {wishlistedProducts.length > 0 && (
          <button
            onClick={onClearWishlist}
            className="text-xs text-stone-500 hover:text-rose-600 font-semibold self-start sm:self-auto"
          >
            Clear Wishlist
          </button>
        )}
      </div>

      {wishlistedProducts.length === 0 ? (
        <div className="bg-white rounded-2xl border border-stone-200 p-12 text-center max-w-lg mx-auto space-y-4">
          <div className="w-16 h-16 rounded-full bg-rose-50 flex items-center justify-center mx-auto text-rose-400">
            <Heart size={30} className="stroke-1" />
          </div>
          <h3 className="font-serif-brand text-xl font-bold text-stone-800">
            No Saved Favorites Yet
          </h3>
          <p className="text-xs text-stone-500">
            Tap the heart icon on any product in our fashion, cosmetics, or lifestyle collections to save them here for later.
          </p>
          <button
            onClick={onContinueShopping}
            className="px-6 py-3 bg-stone-900 hover:bg-stone-800 text-white rounded-xl text-xs font-semibold inline-flex items-center gap-2 transition"
          >
            <ArrowLeft size={14} />
            <span>Browse Products</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {wishlistedProducts.map((product) => (
            <div 
              key={product.id}
              className="bg-white rounded-xl border border-stone-200 overflow-hidden flex flex-col justify-between hover:shadow-md transition"
            >
              <div 
                className="relative aspect-square sm:aspect-[4/5] bg-stone-100 cursor-pointer"
                onClick={() => onSelectProduct(product)}
              >
                <img
                  src={product.images[0]}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onRemoveFromWishlist(product.id);
                  }}
                  className="absolute top-3 right-3 p-2 bg-white/90 text-rose-500 hover:bg-white rounded-full shadow-xs transition"
                  title="Remove from favorites"
                >
                  <Trash2 size={16} />
                </button>
              </div>

              <div className="p-4 space-y-3">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-stone-400">
                    {product.categoryLabel}
                  </span>
                  <h3 
                    onClick={() => onSelectProduct(product)}
                    className="font-bold text-stone-900 text-sm hover:text-stone-700 cursor-pointer truncate mt-0.5"
                  >
                    {product.name}
                  </h3>
                  <div className="text-sm font-extrabold text-stone-900 mt-1">
                    {formatPKR(product.price)}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 pt-2 border-t border-stone-100">
                  <button
                    onClick={() => onSelectProduct(product)}
                    className="py-2 text-xs font-semibold text-stone-700 bg-stone-100 hover:bg-stone-200 rounded-lg transition text-center"
                  >
                    Details
                  </button>
                  <button
                    onClick={() => onAddToCart(product)}
                    className="py-2 text-xs font-semibold text-white bg-stone-900 hover:bg-stone-800 rounded-lg flex items-center justify-center gap-1.5 transition text-center"
                  >
                    <ShoppingBag size={13} />
                    <span>Add to Bag</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

    </div>
  );
};
