import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.zavellomarket.app',
  appName: 'Zavello Market',
  webDir: 'dist'
};

export default config;
